"""This module contains all classes and methods related to sskp structs."""

# pylint settings

# disable warnings of fields initialized outside init
# pylint: disable=W0201
# disable warnings of mixed-case fields
# pylint: disable=C0103
# disable warnings of no public methods
# pylint: disable=R0903

import ctypes

import triple

__author__ = "Sakari Stenudd"
__date__ = "$Mar 17, 2011 10:21:11 AM$"

# CONSTANT DEFINITIONS
SSIP_ADDR_LEN = 16
SSNOTA_VDID_LEN = 17
SSSIB_INFO_MAX = 64

# STRUCT DEFINITIONS

class _SsRdfEntry(ctypes.Structure):
    """RDF triple entry structure (subject, predicate or object)."""
    _fields_ = [('type',  ctypes.c_int),   # SsRdfType
                ('value', ctypes.c_char_p),
                ('key',   ctypes.c_char_p)]

class _SsTriple(ctypes.Structure):
    """RDF triple structure."""
    _fields_ = [('subject',   _SsRdfEntry),
                ('predicate', _SsRdfEntry),
                ('object',    _SsRdfEntry)]

class _SsTcpAddr(ctypes.Structure):
    """TCP/IP address structure."""
    _fields_ = [('ip',   ctypes.c_char * SSIP_ADDR_LEN), # array
                ('port', ctypes.c_uint)]

class _SsNotaAddr(ctypes.Structure):
    """NoTA address structure."""
    _fields_ = [('vdid', ctypes.c_char * SSNOTA_VDID_LEN), # array
                ('sid',  ctypes.c_uint),
                ('port', ctypes.c_uint)]

class _SsTlsAddr(ctypes.Structure):
    """TCP/IP address structure."""
    _fields_ = [('ip',   ctypes.c_char * SSIP_ADDR_LEN), # array
                ('port', ctypes.c_uint),
                ('cert', ctypes.c_char_p),
                ('privKey', ctypes.c_char_p),
                ('rootCert', ctypes.c_char_p),
                ('rootCertDir', ctypes.c_char_p),
                ('algorithms', ctypes.c_char_p)]

class _SsAddress(ctypes.Union):
    """Smart space address structure."""
    _fields_ = [('tcpAddr',  _SsTcpAddr),
                ('notaAddr', _SsNotaAddr),
                ('tlsAddr',  _SsTlsAddr)]

class _SsSocket(ctypes.Structure):
    """Ss socket structure."""
    _fields_ = [('sock', ctypes.c_int),
                ('session',  ctypes.c_void_p)]

# disable warnings of too many instance attributes
# pylint: disable=R0902
class _Ss(ctypes.Structure):
    """Smart space structure."""
    _fields_ = [('buf',          ctypes.c_char_p),
               ('bufMaxLen',     ctypes.c_int),
               ('sibInfo',       ctypes.c_char * SSSIB_INFO_MAX),
               ('nodeId',        ctypes.c_char_p),
               ('spaceId',       ctypes.c_char_p),
               ('addrType',      ctypes.c_int), # enum SsAddrType
               ('addr',          _SsAddress),
               ('credentials',   ctypes.c_char_p),
               ('msgType',       ctypes.c_int),  # enum SsMsgType
               ('acType',        ctypes.c_int),  # enum SsAccessCtrlType
               ('sock',          _SsSocket),
               ('sockTimeout',   ctypes.c_int),
               # this may cause problems in some platforms, hopefully not
               ('sem',           ctypes.c_char * 32)]
# pylint: enable=R0902

class _SsSubscription(ctypes.Structure):
    """Subscription structure."""
    _fields_ = [('buf',  ctypes.c_char_p),
                ('bufMaxLen', ctypes.c_int),
                ('id', ctypes.c_int),
                ('sock', _SsSocket),
                ('bufPtr',  ctypes.c_char_p),
                # this may cause problems in some platforms, hopefully not
                ('sem',  ctypes.c_char * 32)]

class SIBInfoMapper:

    """Used by SSKP class to map SIB info between Python and SSKP formats.

    This is needed in discovery and join methods.

    SSKP format: C array of Ss structs, or one Ss struct.
    Python format: List of (spaceId, addr, addrType, msgType) tuples, or one
                   such tuple.
    """

    # TCP/IP, NoTA, TLS and Any address types (enum SsAddrType)
    SsAddrTcp, SsAddrNota, SsAddrTls, SsAddrAny = 0x01, 0x02, 0x04, 0xFF
    # Discovery methods: Environment variable (SIB_INFO), DNS-SD (Zeroconf), Any
    # (enum SsDiscoveryType)
    SsDiscoveryEnv, SsDiscoveryMdns, SsDiscoveryAny = 0x01, 0x02, 0xFF
    # Message types: XML-SSAP, WAX-SSAP (enum SsMsgType)
    SsMsgXml, SsMsgWax = 0x01, 0x02
    # Access control types (enum SsAccessCtrlType)
    SsAcNone, SsAcNodeLock = 0x00, 0x01

    searchmaskmap = {'TCP': SsAddrTcp,
                     'TLS': SsAddrTls,
                     'NoTA': SsAddrNota}
    addresstypemap = {SsAddrTcp: 'TCP',
                      SsAddrTls: 'TLS',
                      SsAddrNota: 'NoTA'}
    discovermaskmap = {'ENV': SsDiscoveryEnv,
                       'MDNS': SsDiscoveryMdns}
    msgtypemap = {SsMsgXml: 'XML',
                  SsMsgWax: 'WAX'}
    actypemap = {SsAcNone: None,
                 SsAcNodeLock: 'NODE'}

    def __init__(self, buflen, node_id, timeout):
        """Set buflen variable, is used for length of the SSAP msg buffer."""
        self._buflen = buflen
        self._node_id = node_id
        self._timeout = timeout

    def create_discovery_structs(self, searchmasks, discovermasks, maxcount):
        """Create three parameters (C structures) needed in sskp discovery.

        The function parameters are:
        searchmask -- List of searched address types. Supported values are
            currently 'TCP', 'TLS' and 'NoTA'.
        diskovermask -- List of discovery methods. Supported values are
            currently 'ENV' (checks environment variable SIB_INFO) and 'MDNS'
            (DNS service discovery i.e. Zeroconf/Bonjour/Avahi).
        maxcount -- Maximum number of returned SIB info tuples.

        The returned values are:
        ss_array -- C array of Ss structures, length maxcount.
        ss_searchmask -- Address flags mapped to sskp format.
        ss_discoverymask -- Discovery method flags mapped to sskp format.

        The return value is tuple (ss_array, ss_searchmask, ss_discoverymask)
        """
        ss_searchmask = 0
        ss_discovermask = 0
        for mask in searchmasks:
            ss_searchmask |= self.searchmaskmap.get(mask, 0)
        for mask in discovermasks:
            ss_discovermask |= self.discovermaskmap.get(mask, 0)
        if ss_searchmask == 0:
            ss_searchmask = self.SsAddrAny
        if ss_discovermask == 0:
            ss_discovermask = self.SsDiscoveryAny
        ss_array = (_Ss * maxcount)()
        for ss_struct in ss_array:
            # Set buffer fields
            buf = ctypes.create_string_buffer(self._buflen)
            ss_struct.buf = ctypes.cast(buf, ctypes.c_char_p)
            ss_struct.bufMaxLen = self._buflen
        return ss_array, ss_searchmask, ss_discovermask

    def get_found_spaces(self, spaces):
        """Transform the results of sskp discovery function to Python form.

        spaces -- An array of _Ss structures, i.e. found smart spaces.

        The results form will be a list of tuples
        (spaceId, addr, addrType, msgType, acType)
        in which addr is an address dict:
        If addrType == "TCP", addr is dict {'ip': <ip>, 'port': <port>).
        If addrType == "NoTA", addr is tuple {'sid': <sid>, 'port': <port>).
        If addrType == "TLS", addr is dict {'ip': <ip>, 'port': <port>,
                                            'cert': None, 'privKey': None,
                                            'rootCert': None,
                                            'rootCertDir': None,
                                            'algorithms': None).
            The KP should fill the needed values.
        
        In case of TLS address, the addr dict should be extended before the
        join with values for keys 'cert', 'privKey', 'rootCert',
        'rootCertDir' and 'algorithms'.
        """
        ret_spaces = []
        for space in spaces:
            space_id = space.spaceId
            sskp_addr_type = space.addrType
            addr = None
            addr_type = self.addresstypemap.get(sskp_addr_type, None)
            if sskp_addr_type == self.SsAddrTcp:
                addr = {'ip':space.addr.tcpAddr.ip,
                        'port': space.addr.tcpAddr.port}
            elif sskp_addr_type == self.SsAddrNota:
                addr = {'sid': space.addr.notaAddr.sid,
                        'port': space.addr.notaAddr.port}
            elif sskp_addr_type == self.SsAddrTls:
                addr = {'ip':space.addr.tcpAddr.ip,
                        'port': space.addr.tcpAddr.port,
                        'cert': None, 'privKey': None, 'rootCert': None,
                        'rootCertDir': None, 'algorithms': None}
            msg_type = self.msgtypemap.get(space.msgType, None)
            ac_type = self.actypemap.get(space.acType, None)
            if addr is None or addr_type is None or msg_type is None:
                print 'error:', addr, addr_type, msg_type
            else:
                ret_spaces.append((space_id, addr, addr_type,
                                   msg_type, ac_type))
        return ret_spaces

    def create_join_struct(self, ssparams, credentials=None):
        """Create the Ss struct needed in join (and other operations).

        ssparams is a tuple (spaceId, addr, addr_type, msg_type, ac_type):
        space_id  -- Smart space name
        addr      -- addrType-dependent address dict (NoTA, TCP or TLS)
        addr_type -- "TCP", "NoTA" or "TLS"
        msg_type  -- "XML" or "WAX"
        ac_type   -- None or "NODE"

        If addrType == "TCP", addr is dict {'ip': <ip>, 'port': <port>).
        If addrType == "NoTA", addr is tuple {'sid': <sid>, 'port': <port>).
        If addrType == "TLS", addr is dict {'ip': <ip>, 'port': <port>,
                                            'cert': <cert>, 'privKey': <key>,
                                            'rootCert': <cert>,
                                            'rootCertDir': <dir>,
                                            'algorithms': <algorithms>}.

        credentials must be given if authentication is used.
        It is a string of form "<username>/<password>".

        Return the filled Ss struct.
        In case of parameter error, return None.
        """
        # last parameter, ac_type, is optional
        if len(ssparams) == 5:
            space_id, addr, addr_type, msg_type, ac_type = ssparams
        else:
            space_id, addr, addr_type, msg_type = ssparams
            ac_type = None
        ss_struct = _Ss()
        # Set fields given as parameter
        # spaceid, addrType, addr, msgType
        ss_struct.spaceId = space_id
        if addr_type == "TCP":
            ss_struct.addrType = self.SsAddrTcp
            ss_struct.addr.tcpAddr.ip = addr['ip']
            ss_struct.addr.tcpAddr.port = addr['port']
        elif addr_type == "NoTA":
            ss_struct.addrType = self.SsAddrNota
            ss_struct.addr.notaAddr.sid = addr['sid']
            ss_struct.addr.notaAddr.port = addr['port']
        elif addr_type == "TLS":
            ss_struct.addrType = self.SsAddrTls
            ss_struct.addr.tlsAddr.ip = addr['ip']
            ss_struct.addr.tlsAddr.port = addr['port']
            ss_struct.addr.tlsAddr.cert = addr['cert']
            ss_struct.addr.tlsAddr.privKey = addr['privKey']
            ss_struct.addr.tlsAddr.rootCert = addr['rootCert']
            ss_struct.addr.tlsAddr.rootCertDir = addr['rootCertDir']
            ss_struct.addr.tlsAddr.algorithms = addr['algorithms']
        else:
            # parameter error
            return None
        if msg_type == "XML":
            ss_struct.msgType = self.SsMsgXml
        elif msg_type == "WAX":
            ss_struct.msgType = self.SsMsgWax
        else:
            # parameter error
            return None
        if ac_type == 'NODE':
            ss_struct.acType = self.SsAcNodeLock
        if credentials is not None:
            ss_struct.credentials = str(credentials)

        # Set socket fields
        ss_struct.sock.sock = -1
        ss_struct.sockTimeout = self._timeout

        # Set buffer fields and node ID
        buf = ctypes.create_string_buffer(self._buflen)
        ss_struct.buf = ctypes.cast(buf, ctypes.c_char_p)
        ss_struct.bufMaxLen = self._buflen
        ss_struct.nodeId = self._node_id
        return ss_struct

    def create_subscribe_struct(self):
        """Create and initialise a subscription struct."""
        subscription = _SsSubscription()
        subscription_buffer = ctypes.create_string_buffer(self._buflen)
        subscription.buf = ctypes.cast(subscription_buffer, ctypes.c_char_p)
        subscription.bufMaxLen = self._buflen
        return subscription

class TripleMapper:

    """Used by SSKP class to map triples between Python and SSKP formats.

    SSKP format: C array of SsTriple structs.
    Python format: List of Triple objects.

    Also used to map SPARQL Select query results from SsEntry arrays
    to Python dict structure.
    """

    # RDF node types in sskp library (enum SsRdfType)
    SsRdfUri, SsRdfLiteral, SsRdfBNode, SsRdfAny = 0x01, 0x02, 0x04, 0xFF

    nodetypemap = {'URI': SsRdfUri,
               'literal': SsRdfLiteral,
               'bnode': SsRdfBNode,
               'any': SsRdfAny}

    def __init__(self, sskp_library):
        """Constructor, does nothing."""
        self._sskp_library = sskp_library

    def create_triple_list(self, sstriples, count):
        """Create a Triple list from a SSKP API triple array.

        sstriples -- Array of _SsTriple objects (=structs).
        count     -- number of triples in array

        Return Triple list.
        """
        triples = []
        i = 0
        for sstriple in sstriples:
            if i >= count:
                break
            i += 1
            subject = sstriple.subject
            predicate = sstriple.predicate
            object_ = sstriple.object
            if subject.type == self.SsRdfUri:
                subject_type = 'uri'
            elif subject.type == self.SsRdfLiteral:
                subject_type = 'literal'
            else:
                subject_type = 'bnode'
            if object_.type == self.SsRdfUri:
                object_type = 'uri'
            elif object_.type == self.SsRdfLiteral:
                object_type = 'literal'
            else:
                object_type = 'bnode'
            triples.append(triple.to_triple(subject.key, predicate.key,
                                            object_.key,
                                            subject_type, object_type))
        return triples

    def create_sskp_triples(self, triples, trbuflen=None):
        """Create a triple set compatible with SSKP API.

        triples  -- List of Triple objects.
        trbuflen -- Length of the reserved triple buffer.
                    If the operation is query or subscribe, space must be
                    reserved for results also. In this case, this parameter
                    must be used. If not given, does not reserve extra space.

        Return _SsTriple array.
        If length of triples parameter is 0, returns an empty array
        of size trbuflen.
        """
        if trbuflen is None:
            buf_count = len(triples)
        else:
            # must reserve extra space for query results
            buf_count = trbuflen
        sstriples = (_SsTriple * buf_count)()
        for i, (subject, predicate, object_) in enumerate(triples):
            if subject is None:
                subject_type = self.SsRdfAny
                subject_value = None
            else:
                subject_type = self.nodetypemap[subject.nodetype]
                subject_value = subject.value
            if predicate is None:
                predicate_type = self.SsRdfAny
                predicate_value = None
            else:
                predicate_type = self.nodetypemap[predicate.nodetype]
                predicate_value = predicate.value
            if object_ is None:
                object_type = self.SsRdfAny
                object_value = None
            else:
                object_type = self.nodetypemap[object_.nodetype]
                object_value = object_.value
            self._sskp_library.SsTripleSet(ctypes.byref(sstriples[i]),
                                    subject_value, subject_type,
                                    predicate_value, predicate_type,
                                    object_value, object_type)
        return sstriples

    def create_sskp_entries(self, count):
        """Create and return an array of _SsRdfEntry structures."""
        entriestype = _SsRdfEntry * count
        entries = entriestype()
        return entries

    def get_sparql_results(self, entries, count):
        """Create a list of result dicts for SPARQL query from a SsEntry array.

        entries -- Array of SsEntry objects (=structs).
        count   -- number of triples in array

        Return list of dicts {key: node}, where
        key  -- variable name
        node -- a Node object (URI, bNode or Literal)

        So every dict is one result set.
        """
        return_entries = []
        current_entry = dict()
        i = 0
        for entry in entries:
            if i >= count:
                break
            i += 1
            type_ = entry.type
            value = entry.value
            key = entry.key
            if type_ == self.SsRdfUri:
                node = triple.URI(value)
            elif type_ == self.SsRdfLiteral:
                node = triple.Literal(value)
            else:
                node = triple.bNode(value)
            if key in current_entry:
                return_entries.append(current_entry)
                current_entry = dict()
            current_entry[key] = node
        return_entries.append(current_entry)
        return return_entries
    