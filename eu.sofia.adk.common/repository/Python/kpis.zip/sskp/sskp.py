"""This module defines API for using sskp library."""

# pylint settings
# disable warnings of deprecated modules (string is false positive)
# pylint: disable=W0402

import threading # for subscription checking
import ctypes
import random # for creating random nodeId
import string # for creating random nodeId
import atexit # for calling SsTerminate()
import os # for Windows / Linux test

import sskpstruct

__author__ = "Sakari Stenudd"
__date__ = "$Jan 28, 2011 1:38:11 PM$"

if os.name == 'posix':
    # Linux
    SSKP_LIBRARY = ctypes.cdll.LoadLibrary('libsskp.so')
elif os.name == 'nt':
    # Windows, sskp.dll must be in PATH
    SSKP_LIBRARY = ctypes.cdll.sskp
else:
    raise OSError('Only Windows and Linux (Posix) operating systems'
                  ' are supported!')


# CONSTANT DEFINITIONS
SSBUFFER_LEN     = 16384
SSSOCKET_TIMEOUT = 5000

RESULTS_LEN = 1024
    
class SSKPException(Exception):
    """Exception raised in errors.
    
    This class contains error codes returned by sskp library
    as class variables.
    """

    # Error codes returned by the sskp library (enum SsErrno).
    SsErrNone = 0          # OK
    SsErrComm = -1         # KP<->SIB communication error
    SsErrMsg = -2          # KP<->SIB message parsing error
    SsErrTimeout = -3      # Timeout
    SsErrSib = -100        # General SIB error
    SsErrSibBadReq = -101  # SIB bad request (i.e. parameter error)
    SsErrSibPerm = -102    # Permission/access denied of requested SIB action
    SsErrSibNoSpace = -103 # SIB is out of resources
    SsErrSibNoSys = -104   # Requested action not implemented in SIB
    SsErrKp = -200         # General KP error
    SsErrKpBadReq = -201   # KP bad request (i.e parameter error)
    SsErrKpNoSpace = -202  # KP is out of resources
    SsErrKpNoSys = -203    # Requested action not implemented in KP

    _short_descriptions = {
        SsErrNone: 'SsErrNone',
        SsErrComm: 'SsErrComm',
        SsErrMsg: 'SsErrMsg',
        SsErrTimeout: 'SsErrTimeout',
        SsErrSib: 'SsErrSib',
        SsErrSibBadReq: 'SsErrSibBadReq',
        SsErrSibPerm: 'SsErrSibPerm',
        SsErrSibNoSpace: 'SsErrSibNoSpace',
        SsErrSibNoSys: 'SsErrSibNoSys',
        SsErrKp: 'SsErrKp',
        SsErrKpBadReq: 'SsErrKpBadReq',
        SsErrKpNoSpace: 'SsErrKpNoSpace',
        SsErrKpNoSys: 'SsErrKpNoSys'
    }

    _long_descriptions = {
        SsErrNone: 'OK',
        SsErrComm: 'KP<->SIB communication error',
        SsErrMsg: 'KP<->SIB message parsing error',
        SsErrTimeout: 'Timeout',
        SsErrSib: 'General SIB error',
        SsErrSibBadReq: 'SIB bad request, i.e. parameter error',
        SsErrSibPerm: 'Permission/access denied of requested SIB action',
        SsErrSibNoSpace: 'SIB is out of resources',
        SsErrSibNoSys: 'Requested action not implemented in SIB',
        SsErrKp: 'General KP error',
        SsErrKpBadReq: 'KP bad request, i.e parameter error',
        SsErrKpNoSpace: 'KP is out of resources',
        SsErrKpNoSys: 'Requested action not implemented in KP'
    }

    def __init__(self, code, msg=None, longmsg=None):
        Exception.__init__(self, code)
        self.code = code
        if msg is None:
            self.msg = self._errno_short_description(code)
        else:
            self.msg = msg
        if longmsg is None:
            self.longmsg = self._errno_long_description(code)
        else:
            self.longmsg = longmsg

    def __str__(self):
        return repr(self.code) + ' ' + self.msg + ' ' + self.longmsg
    
    def _errno_short_description(self, errno):
        """Return a short description of the error code."""
        if errno in self._short_descriptions:
            return self._short_descriptions[errno]
        return ''

    def _errno_long_description(self, errno):
        """Return a long description of the error code."""
        if errno in self._long_descriptions:
            return self._long_descriptions[errno]
        return ''

class BadRequestException(SSKPException):
    """An SSKPException with SsErrKpBadReq code."""
    def __init__(self):
        SSKPException.__init__(self, SSKPException.SsErrKpBadReq)



def _check_error(err):
    """Utility to check error value and raise an exception if needed."""
    if err < 0:
        raise SSKPException(err)
    return True

class SSKP:

    """A wrapper class for C-library sskp."""

    def __init__(self, node_id=None, buflen=SSBUFFER_LEN,
                 resultlen=RESULTS_LEN, timeout=SSSOCKET_TIMEOUT):
        """Construct a KP interface object.

        node_id  -- Identifier of this KP. If not given or None, a random one is
                   used. If given, the last four digits are used if longer than
                   4. If shorter than 4, pre-padded with spaces.
        buflen  -- Maximum length of message buffers. If not given, a default
                   value (16386) is used.
        resultlen -- Maximum number of received results for queries.
                     This parameter tells how much space must be reserved.
                     If not given, a default value (1024) is used.
                     The parameter is also used for a number of results for
                     a SPARQL query,
        timeout -- Socket timeout in ms. If not given, default value of 5000 ms
                   is used. Probably suitable for most uses.
        """
        self.ss_struct = None
        self.resultlen = resultlen
        # node identifier
        if node_id is not None:
            # ensure that string is four-character
            node_id = ('    ' + node_id)[-4:]
        else:
            # generate random four-character string
            charlist = string.ascii_letters + string.digits
            node_id = ''.join(random.sample(charlist, 4))
        # subscribe handler thread objects, saved by id
        self.handlers = dict()
        # for mapping triple representations
        self._triple_mapper = sskpstruct.TripleMapper(SSKP_LIBRARY)
        self._sib_info_mapper = sskpstruct.SIBInfoMapper(buflen, node_id,
                                                         timeout)

    def __del__(self):
        try:
            self.leave()
        except SSKPException:
            # we are not interested in errors in this phase
            pass
        
    def discover(self, searchmask=None, discovermask=None, maxcount=100):
        """Perform smart space discovery.

        searchmask -- List of searched address types. Supported values are
            currently 'TCP', 'TLS' and 'NoTA'.
        diskovermask -- List of discovery methods. Supported values are
            currently 'ENV' (checks environment variable SIB_INFO) and 'MDNS'
            (DNS service discovery i.e. Zeroconf/Bonjour/Avahi).
        maxcount -- Maximum number of returned SIB info tuples. Default is 100.

        Return found smart spaces as a list of tuples
        (spaceId, addr, addrType, msgType, acType).
        """
        if searchmask is None:
            searchmask = []
        if discovermask is None:
            discovermask = []
        ret = self._sib_info_mapper.create_discovery_structs(searchmask,
                                                       discovermask, maxcount)
        ss_array, ss_searchmask, ss_discovermask = ret
        count = SSKP_LIBRARY.SsDiscover(ss_array, maxcount,
                                     ss_searchmask, ss_discovermask)
        # raises an exception if count < 0
        _check_error(count)
        # copy ss info to tuple
        # (spaceId, addr, addrType, msgType)
        return self._sib_info_mapper.get_found_spaces(ss_array[:count])

    def join(self, ssparams, credentials=None):
        """Join a smart space.

        ssparams is a tuple (spaceId, addr, addrType, msgType, acType).
        spaceId -- Smart space name
        addr    -- addrType-dependent address dict (NoTA, TCP or TLS)
        addrType -- "TCP", "NoTA" or "TLS"
        msgType  -- "XML" or "WAX"
        acType   -- None or "NODE"

        If addrType == "TCP", addr is dict {'ip': <ip>, 'port': <port>).
        If addrType == "NoTA", addr is tuple {'sid': <sid>, 'port': <port>).
        If addrType == "TLS", addr is dict {'ip': <ip>, 'port': <port>,
                                            'cert': <cert>, 'privKey': <key>,
                                            'rootCert': <cert>,
                                            'rootCertDir': <dir>,
                                            'algorithms': <algorithms>}.

        credentials must be given if authentication is used.
        It is a string of form "<username>/<password>".

        Return True if successful.
        Raise BadRequestException if bad parameters.
        Raise SSKPException if other exception occurs.
        """
        ss_struct = self._sib_info_mapper.create_join_struct(ssparams,
                                                             credentials)
        if ss_struct is None:
            raise BadRequestException()
        err = SSKP_LIBRARY.SsJoin(ctypes.byref(ss_struct))
        if _check_error(err):
            # join successful
            self.ss_struct = ss_struct
        return True

    def leave(self):
        """Leave the smart space, if joined.
        
        If not joined, raise SsErrKpBadReq exception.
        If joined, return True or raise exception with returned error code.
        """
        if self.ss_struct is not None:
            ret = SSKP_LIBRARY.SsLeave(ctypes.byref(self.ss_struct))
            self.ss_struct = None
            return _check_error(ret)
        raise BadRequestException()


    def insert(self, triples):
        """Insert the triples to SIB to which this KP is joined.
        
        triples -- List of Triple objects.

        If not joined, raise SsErrKpBadReq exception.
        Otherwise, return triples or exception with status code from C API.

        Return triple format is list of tuples (s, p, o),
        where s, p and o are URIs returned by SIB which can be used to refer to
        the node.
        For RIBS, this is urn which specifies the internal index in RIBS.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        sstriples = self._triple_mapper.create_sskp_triples(triples)
        triple_count = len(sstriples)
        ret = SSKP_LIBRARY.SsInsert(ctypes.byref(self.ss_struct),
                                 sstriples, triple_count)
        # return assigned urns / uris
        urns = []
        for sst in sstriples:
            subject = sst.subject.key
            predicate = sst.predicate.key
            object_ = sst.object.key
            urns.append((subject, predicate, object_))
        if _check_error(ret):
            return urns

    def remove(self, triples):
        """Remove triples from a SIB to which this KP is joined.
        
        triples -- List of Triple objects.

        If not joined, raise SsErrKpBadReq exception.
        Otherwise, return True or exception with status code from C API.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        sstriples = self._triple_mapper.create_sskp_triples(triples)
        triple_count = len(sstriples)
        ret = SSKP_LIBRARY.SsRemove(ctypes.byref(self.ss_struct),
                                 sstriples, triple_count)
        return _check_error(ret)

    def update(self, removed, inserted):
        """Update triples in a SIB to which this KP is joined.

        removed -- List of Triple objects to be removed.
        inserted -- List of Triple objects to be inserted.

        If not joined, raise SsErrKpBadReq exception.
        Otherwise, return True or exception with status code from C API.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        rcount = len(removed)
        icount = len(inserted)
        triples = removed + inserted
        sstriples = self._triple_mapper.create_sskp_triples(triples)
        ret = SSKP_LIBRARY.SsUpdate(ctypes.byref(self.ss_struct),
                                 sstriples, rcount, icount)
        return _check_error(ret)

    def query(self, triples):
        """Query triples from a SIB to which this KP is joined.

        triples -- List of Triple objects.

        If not joined, raise SsErrKpBadReq exception.
        If error occurs, raise exception with status code.
        Otherwise, return the received Triple list.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        count = len(triples)
        sstriples = self._triple_mapper.create_sskp_triples(triples,
                                                            self.resultlen)
        maxcount = len(sstriples)
        # Note that ret can be > maxcount.
        # Currently the situation is not handled.
        ret = SSKP_LIBRARY.SsQuery(ctypes.byref(self.ss_struct),
                                sstriples, count, maxcount)
        if ret < 0:
            # Raises an exception
            _check_error(ret)
        rettr = self._triple_mapper.create_triple_list(sstriples, ret)
        return rettr

    def subscribe(self, triples, handler):
        """Subscribe triples from a SIB to which this KP is joined.

        Start a new thread checking for subscription indications.

        triples -- List of Triple objects to query.
        handler -- The callback function to call for subscription indication

        If not joined, raise SsErrKpBadReq exception.
        If error occurs, raise exception with status code.
        Otherwise, return subscription id and received Triple list.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        count = len(triples)
        sstriples = self._triple_mapper.create_sskp_triples(triples,
                                                            self.resultlen)
        maxcount = len(sstriples)
        # Create subscription struct
        subscription = self._sib_info_mapper.create_subscribe_struct()
        # Note that ret can be > maxcount.
        # Currently the situation is not handled.
        ret = SSKP_LIBRARY.SsSubscribe(ctypes.byref(self.ss_struct),
                                    ctypes.byref(subscription),
                                    sstriples, count, maxcount)
        # Raises an exception if ret < 0
        _check_error(ret)
        rettr = self._triple_mapper.create_triple_list(sstriples, ret)

        # start subscription thread
        subs = _SubscribeHandler(self.ss_struct, subscription,
                                 handler, self.resultlen)
        subs.start()
        # save _SubscribeHandler object to a dict
        sid = subscription.id
        self.handlers[sid] = subs
        return sid, rettr

    def unsubscribe(self, subscription_id):
        """End a subscription in a SIB to which this KP is joined.

        subscription_id -- The ID of the subscription which to end.

        If not joined, raise SsErrKpBadReq exception.
        If no such subscription, raise SsErrKpBadReq exception.
        If error occurs, raise exception with status code.
        Otherwise, return True.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        if not subscription_id in self.handlers:
            raise BadRequestException()
        handler = self.handlers.pop(subscription_id)
        if not handler.isAlive():
            print 'The subscription has already been terminated!'
            return False
        subscription = handler.subscription_struct

        handler.stop_thread()
        handler.join()

        ret = SSKP_LIBRARY.SsUnsubscribe(ctypes.byref(self.ss_struct),
                                      ctypes.byref(subscription))
        return _check_error(ret)

    def sparql_query(self, query):
        """Perform a SPARQL query to a SIB to which this KP is joined.

        query -- The SPARQL string.

        If not joined, raise SsErrKpBadReq exception.
        If error occurs, raise exception with status code.
        Otherwise, Return results as a list of dicts [key: (type, value], where
        key   -- variable name
        type  -- 'uri' or 'literal' or 'bnode'
        value -- uri or literal string

        Every dict represents one result set.
        """
        if self.ss_struct is None:
            # not joined
            raise BadRequestException()
        maxcount = self.resultlen
        entries = self._triple_mapper.create_sskp_entries(maxcount)
        ret = SSKP_LIBRARY.SsSelect(ctypes.byref(self.ss_struct),
                                 query, entries, maxcount)

        # Raises an exception if ret < 0
        _check_error(ret)
        retentr = self._triple_mapper.get_sparql_results(entries, ret)
        return retentr
    
    
class _SubscribeHandler(threading.Thread):

    """A handler thread class for checking subscribe indications."""
    
    def __init__(self, ss_struct, subscription_struct,
                 handler, resultlen):
        """Init instance variables.
        
        ss_struct -- _Ss ctypes.Structure instance, used to access SIB
        subscription -- _SsSubscription ctypes.Structure instance
        handler -- Handler method to call with added and removed triples
        resultlen -- Maximum number of received results
        """
        threading.Thread.__init__(self)
        self._triple_mapper =  sskpstruct.TripleMapper(SSKP_LIBRARY)
        self.ss_struct = ss_struct
        self.subscription_struct = subscription_struct
        self._handler = handler
        self._stop_event = threading.Event()
        self._maxcount = resultlen
        # How often the stop event flag is checked
        self.timeout = 100

    def stop_thread(self):
        """Stop waiting for subscription indications."""
        self._stop_event.set()
        
    def run(self):
        """Start a subscribe indication checking thread."""
        newcount = ctypes.c_int(0)
        sstriples = self._triple_mapper.create_sskp_triples([], self._maxcount)
        while not self._stop_event.isSet():
            ret = SSKP_LIBRARY.SsSubscribeCheck(ctypes.byref(self.ss_struct),
                                        ctypes.byref(self.subscription_struct),
                                        sstriples, self._maxcount,
                                        ctypes.byref(newcount), self.timeout)
            if ret == SSKPException.SsErrTimeout:
                # check flag and continue waiting
                continue
            elif ret == 0:
                # subscription terminated
                break
            elif ret < 0:
                # error, subscription terminated
                break
            elif ret > self._maxcount:
                # ret can be > self._maxcount.
                # Currently the situation is not handled.
                pass
            # succeeded
            count = ret
            ncount = newcount.value
            newtriples = self._triple_mapper.\
                         create_triple_list(sstriples, ncount)
            oldtriples = self._triple_mapper.\
                         create_triple_list(sstriples[ncount:], count - ncount)
            self._handler(newtriples, oldtriples)

def terminate_module():
    """Terminate the sskp library.

    This function is called when the Python interpreter
    is shut down.
    """
    SSKP_LIBRARY.SsTerminate()


# module initialisation
SSKP_LIBRARY.SsInit()
atexit.register(terminate_module)

