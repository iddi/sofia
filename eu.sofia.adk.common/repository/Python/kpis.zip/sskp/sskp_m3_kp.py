"""This module defines a API to SSKP library Python bindings.
This API is compatible with Python KPI API available in the Smart-M3
packet in Sourceforge.
"""

import sskp
from triple import Node, URI, Literal, bNode, Triple

# SSAP Constants

M3_SUCCESS = 'm3:Success'
M3_SIB_NOTIFICATION_RESET = 'm3:SIB.Notification.Reset'
M3_SIB_NOTIFICATION_CLOSING = 'm3:SIB.Notification.Closing'
M3_SIB_ERROR = 'm3:SIB.Error'
M3_SIB_ERROR_ACCESS_DENIED = 'm3:SIB.Error.AccessDenied'
M3_SIB_FAILURE_OUT_OF_RESOURCES = 'm3:SIB.Failure.OutOfResources'
M3_SIB_FAILURE_NOT_IMPLEMENTED = 'm3:SIB.Failure.NotImplemented'

M3_KP_ERROR = 'm3:KP.Error'
M3_KP_ERROR_REQUEST = 'm3:KP.Error.Request'
M3_KP_ERROR_MESSAGE_INCOMPLETE = 'm3:KP.Error.Message.Incomplete'
M3_KP_ERROR_MESSAGE_SYNTAX = 'm3:KP.Error.Message.Syntax'

errmap = {sskp.SsErrno.SsErrNone: M3_SUCCESS,
          sskp.SsErrno.SsErrComm: M3_SIB_ERROR,
          sskp.SsErrno.SsErrMsg: M3_KP_ERROR_MESSAGE_SYNTAX,
          sskp.SsErrno.SsErrTimeout: M3_SIB_ERROR,
          sskp.SsErrno.SsErrSib: M3_SIB_ERROR,
          sskp.SsErrno.SsErrSibBadReq: M3_SIB_ERROR,
          sskp.SsErrno.SsErrSibPerm: M3_SIB_ERROR_ACCESS_DENIED,
          sskp.SsErrno.SsErrSibNoSpace: M3_SIB_FAILURE_OUT_OF_RESOURCES,
          sskp.SsErrno.SsErrSibNoSys: M3_SIB_FAILURE_NOT_IMPLEMENTED,
          sskp.SsErrno.SsErrKp: M3_KP_ERROR,
          sskp.SsErrno.SsErrKpBadReq: M3_KP_ERROR_REQUEST,
          sskp.SsErrno.SsErrKpNoSpace: M3_KP_ERROR,
          sskp.SsErrno.SsErrKpNoSys: M3_KP_ERROR_MESSAGE_INCOMPLETE
          }

# Exceptions

class M3Exception(Exception):
    pass

class KPError(M3Exception):
    def __init__(self, args):
        self.args = args

class SIBError(M3Exception):
    def __init__(self, args):
        self.args = args

class M3Notification(M3Exception):
    def __init__(self, args):
        self.args = args

# KP definitions

class KP:
    def __init__(self, node_id):
        self.sskps = dict()
        self.node_id = node_id

    def discover(self, method = "Manual", browse = True, name = None):
        '''Discover available smart spaces. Currently available
           discovery methods are:
             - Manual: give IP address and port
             - Bonjour discovery (if pyBonjour package has been installed)
           Returns a handle for smart space if method is Manual or
           browse is True, otherwise returns a list of handles
           Handle is a tuple
           (SSName, (connector class, (connector constructor args)))
           '''
        spaces = self.sskp.discover()
        return spaces

    def join(self, dest):
        '''Join a smart space. Argument dest is a smart space handle of form
        (SSName, (connector class, (connector constructor args))).
        join() accepts handles returned by discover() method.
        Returns True if succesful, False otherwise.
        '''
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            kpi = sskp.SSKP(self.node_id)
            self.sskps[dest] = kpi
        try:
            return kpi.join(dest)
        except sskp.SSKPException, ex:
            raise SIBError(errmap[ex.code])

    def leave(self, dest):
        '''Leave a smart space. Argument dest is a smart space handle of form
        (SSName, (connector class, (connector constructor args))).
        leave() accepts handles returned by discover() method.
        Returns True if succesful, False otherwise.
        '''
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            raise SIBError(M3_SIB_ERROR)
        try:
            return kpi.leave()
        except sskp.SSKPException, ex:
            raise SIBError(errmap[ex.code])

    def CreateInsertTransaction(self, dest):
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            kpi = sskp.SSKP(self.node_id)
        c = Insert(kpi)
        return c

    def CloseInsertTransaction(self, trans):
        pass

    def CreateRemoveTransaction(self, dest):
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            kpi = sskp.SSKP(self.node_id)
        c = Remove(kpi)
        return c

    def CloseRemoveTransaction(self, trans):
        pass

    def CreateUpdateTransaction(self, dest):
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            kpi = sskp.SSKP(self.node_id)
        c = Update(kpi)
        return c

    def CloseUpdateTransaction(self, trans):
        pass

    def CreateSubscribeTransaction(self, dest, once = False):
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            kpi = sskp.SSKP(self.node_id)
        c = Subscribe(kpi)
        return c

    def CloseSubscribeTransaction(self, trans):
        '''Closes a subscribe transaction
        '''
        trans.close()

    def CreateQueryTransaction(self, dest):
        '''Creates a query transaction for querying information
        in a smart space.
        Returns an instance of Query(Transaction) class
        '''
        if dest in self.sskps:
            kpi = self.sskps[dest]
        else:
            kpi = sskp.SSKP(self.node_id)
        c = Query(kpi)
        return c

    def CloseQueryTransaction(self, trans):
        pass

class Transaction:
    '''Abstract base class for M3 operations.
    '''
    def __init__(self, kpi):
        self.sskp = kpi

    def close(self):
        pass


class Insert(Transaction):
    '''Class handling Insert transactions.
    '''

    def send(self, payload, pl_type = "python",
             encoding = "rdf-m3", confirm = True):
        if pl_type == "python":
            if len(payload) == 0:
                # would cause an error in sskp
                return False
            try:
                return 'OK', self.sskp.insert(payload)
            except sskp.SSKPException, ex:
                raise SIBError(errmap[ex.code])
        else:
            raise SIBError(M3_KP_ERROR_REQUEST)

class Remove(Transaction):
    def remove(self, triples, type = 'rdf-m3', confirm = True):
        print 'REMOVE', triples
        if type.lower() == 'rdf-m3':
            if not isinstance(triples, list):
                triples = [triples]
            if len(triples) == 0:
                # would cause an error in sskp
                return False
            try:
                return self.sskp.remove(triples)
            except sskp.SSKPException, ex:
                raise SIBError(str(ex))
        else:
            print "Only rdf-m3 encoding supported at moment!"
            raise SIBError(M3_SIB_FAILURE_NOT_IMPLEMENTED)

class Update(Transaction):
    def update(self, i_triples, i_enc,
               r_triples, r_enc, confirm = True):
        if len(r_triples) == 0 and len(i_triples) == 0:
            # would cause an error in sskp
            return False
        try:
            return self.sskp.update(r_triples, i_triples)
        except sskp.SSKPException, ex:
            raise SIBError(errmap[ex.code])

class Query(Transaction):
    def wql_values_query(self, start_node, path):
        raise KPError(M3_KP_ERROR)

    def wql_related_query(self, start_node, end_node, path):
        raise KPError(M3_KP_ERROR)

    def wql_nodetypes_query(self, node):
        raise KPError(M3_KP_ERROR)

    def wql_istype_query(self, node, nodetype):
        raise KPError(M3_KP_ERROR)

    def wql_issubtype_query(self, subtype, supertype):
        raise KPError(M3_KP_ERROR)

    def rdf_query(self, triples):
        if not isinstance(triples, list):
            triples = [triples]
        if len(triples) == 0:
            # would cause an error in sskp
            return []
        try:
            return self.sskp.query(triples)
        except sskp.SSKPException, ex:
            raise SIBError(errmap[ex.code])

    def sparql_query(self, query):
        try:
            ret = self.sskp.sparql_query(query)
        except sskp.SSKPException, ex:
            raise SIBError(str(ex))
        # convert results
        variables = []
        bindings = []
        if len(ret) > 0:
            firstres = ret[0]
            for varname in firstres:
                variables.append(varname)
        for res in ret:
            curbind = []
            for varname in variables:
                # order is important here
                curbind.append(res[varname])
            bindings.append(curbind)
        return (variables, bindings)


class Subscribe(Transaction):
    def __init__(self, sskp):
        Transaction.__init__(self, sskp)
        self.id = id

    def subscribe_rdf(self, triple, msg_handler):
        if type(triple) != list:
            triple = [triple]
        if len(triple) == 0:
            # would cause an error in sskp
            return []
        try:
            ret = self.sskp.subscribe(triple, msg_handler.handle)
            print 'SUBSCRIPTION ID:', ret[0]
            self.id, initial_result = ret
        except sskp.SSKPException, ex:
            raise SIBError(errmap[ex.code])
        return initial_result

    def subscribe_wql_values(self, start_node, path,
                             msg_handler):
        raise KPError(M3_KP_ERROR)

    def subscribe_wql_related(self, start_node, end_node, path,
                             msg_handler):
        raise KPError(M3_KP_ERROR)

    def subscribe_wql_nodetypes(self, node, msg_handler):
        raise KPError(M3_KP_ERROR)

    def subscribe_wql_istype(self, node, type,
                             msg_handler):
        raise KPError(M3_KP_ERROR)

    def subscribe_wql_issubtype(self, subtype, supertype,
                             msg_handler):
        raise KPError(M3_KP_ERROR)

    def close(self):
        try:
            print 'CLOSING SUBSCRIPTION, ID:', self.id
            return self.sskp.unsubscribe(self.id)
        except sskp.SSKPException, ex:
            raise SIBError(errmap[ex.code])


class Connector:
    pass

class TCPConnector(Connector):
    def __init__(self, arg_tuple):
        (self.sib_address, self.port), self.enc = arg_tuple
        self.connName = "TCP"
