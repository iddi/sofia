__author__="Sakari Stenudd"
__date__ ="$Mar 18, 2011 9:54:18 AM$"