"""This module contains definitions needed for Triple objects.

The classes are modified from m3_kp.py in Smart-M3 package,
and they are using the same interface.
These objects are used by sskp KP interface library Python bindings.
"""

__author__="Sakari Stenudd"
__date__ ="$Feb 2, 2011 3:25:49 PM$"


# Classes for URI, Literal, bNode and Triple

class Node:
    
    """Common methods for Node classes.
    
    Should not be instantiated.
    Default methods work for URIs and bNodes, Literals must override them.
    """
    def __init__(self, value, nodetype, reprtemplate):
        self.value = value
        self.nodetype = nodetype
        self.reprtemplate = reprtemplate

    def __str__(self):
        return str(self.value)

    def __repr__(self):
        return self.reprtemplate % self.value

    def __eq__(self, other):
        if not isinstance(other, Node):
            return False
        if self.nodetype != other.nodetype:
            return False
        return self.value == other.value
        
    def __ne__(self, other):
        if not isinstance(other, Node):
            return True
        if self.nodetype != other.nodetype:
            return True
        return self.value != other.value
        
    def __hash__(self):
        return hash(self.value)
        

class URI(Node):
    def __init__(self, value):
        Node.__init__(self, value, "URI", "<%s>")


class bNode(Node):
    def __init__(self, value):
        Node.__init__(self, value, "bnode", "_:%s")
        

class Literal(Node):
    def __init__(self, value, lang = None, dt = None):
        Node.__init__(self, value, "literal", '"%s"')
        if lang and dt:
            raise ValueError("lang and dt in Literal are mutually exclusive")
        self.lang = lang
        self.dt = dt

    def __eq__(self, other):
        if not isinstance(other, Literal):
            return False
        else:
            return self.value == other.value and \
                   self.lang == other.lang and \
                   self.dt == other.dt

    def __ne__(self, other):
        if not isinstance(other, Literal):
            return True
        else:
            return self.value != other.value or \
                   self.lang != other.lang or \
                   self.dt != other.dt

    def __hash__(self):
        if lang and not dt:
            return hash(self.value+str(self.lang))
        elif dt and not lang:
            return hash(self.value+str(self.dt))
        else:
            return hash(self.value)


class Triple(tuple):

    """Same class as the one in m3_kp.py, except encode_to_m3 is removed.

    The method is not used by sskp API.
    Also raises TypeError in case of wrong parameters, not KPError.
    """

    def __new__(cls, *args):
        if len(args) == 3:
            s, p, o = tuple(args)
        elif len(args) == 1:
            s, p, o = tuple(args[0])
        else:
            raise KPError("Not a triple")
        for i in (s, p, o):
            if not (isinstance(i, Node) or i == None):
                raise TypeError("s, p, o should be instances of Node")
        return tuple.__new__(cls, (s, p, o))

    def __eq__(self, other):
        return self[0]==other[0] and self[1]==other[1] and self[2]==other[2]

    def __ne__(self, other):
        return self[0]!=other[0] or self[1]!=other[1] or self[2]!=other[2]

def to_triple(subj, pred, obj, st='uri', ot='uri'):
    """Return a Triple object corresponding to the parameters."""
    RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
    RDFS = 'http://www.w3.org/2000/01/rdf-schema#'
    if subj != None:
        if st == 'uri' or st == 'URI':
            if subj.startswith('rdf:'):
                subj = subj.replace('rdf:', RDF, 1)
            elif subj.startswith('rdfs:'):
                subj = subj.replace('rdfs:', RDFS, 1)
            subj = URI(subj)
        else:
            subj = bNode(subj)
    if pred != None:
        if pred.startswith('rdf:'):
            pred = pred.replace('rdf:', RDF, 1)
        elif pred.startswith('rdfs:'):
            pred = pred.replace('rdfs:', RDFS, 1)
        pred = URI(pred)
    if obj != None:
        if ot == 'uri' or ot == 'URI':
            if obj.startswith('rdf:'):
                obj = obj.replace('rdf:', RDF, 1)
            elif obj.startswith('rdfs:'):
                obj = obj.replace('rdfs:', RDFS, 1)
            obj = URI(obj)
        elif ot == 'literal':
            obj = Literal(obj)
        else:
            obj = bNode(obj)
    return Triple(subj, pred, obj)