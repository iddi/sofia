
__author__="sakari"
__date__ ="$28.7.2009 9:06:20$"

from ribs_m3_kp import RIBS_KP
from ribs_m3_kp import RIBS_TCPConnector
from m3_kp import KP as m3KP
from m3_kp import TCPConnector
from m3_kp import Triple, URI, bNode, Literal
from m3_kp import SIBError
import socket
import uuid

kpnum = 0

class KP:
    def __init__(self, ssname, ssaddress, ssport, ssaURI=None):
        """Initializes the variables of the KP.
        Does not join yet. ssaURI is the URI of the Smart Space Application
        in which this KP is.
        """
        global kpnum
        print 'Running kp', kpnum, ssaURI
        self.kpnum = kpnum
        kpnum += 1

        #the node name does not matter; we take a random one
        self.node_id = str(uuid.uuid4())
        self.params = (ssname, ssaddress, ssport)
        self.m3node = m3KP(self.node_id)
        self.m3sspace = (ssname, (TCPConnector, (ssaddress, ssport)))
        self.ribsnode = RIBS_KP(self.node_id)
        self.ribssspace = (ssname, (RIBS_TCPConnector, (ssaddress, ssport)))
        self.node = self.m3node
        self.sspace = self.m3sspace
        self.ribsused = False
        self.subscriptions = []
        self.joined = False
        self.ssa = ssaURI

    def __del__(self):
        """
        Closes the subscriptions and leaves the smart space.
        """
        self.leave()
        print 'deleted kp', self.kpnum

    def toTriple(self, subj, pred, obj, st='uri', ot='uri'):
        '''Returns a Triple object corresponding to the parameters.'''
        RDFTYPE = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type'
        RDF = 'http://www.w3.org/1999/02/22-rdf-syntax-ns#'
        RDFS = 'http://www.w3.org/2000/01/rdf-schema#'
        if subj != None:
            if st == 'uri' or st == 'URI':
#                if subj == 'rdf:type':
#                    subj = RDFTYPE
                if subj.startswith('rdf:'):
                    subj = subj.replace('rdf:', RDF, 1)
                elif subj.startswith('rdfs:'):
                    subj = subj.replace('rdfs:', RDFS, 1)
                subj = URI(subj)
            else:
                subj = bNode(subj)
        if pred != None:
#            if pred == 'rdf:type':
#                pred = RDFTYPE
            if pred.startswith('rdf:'):
                pred = pred.replace('rdf:', RDF, 1)
            elif pred.startswith('rdfs:'):
                pred = pred.replace('rdfs:', RDFS, 1)
            pred = URI(pred)
        if obj != None:
            if ot == 'uri' or ot == 'URI':
#                if obj == 'rdf:type':
#                    obj = RDFTYPE
                if obj.startswith('rdf:'):
                    obj = obj.replace('rdf:', RDF, 1)
                elif obj.startswith('rdfs:'):
                    obj = obj.replace('rdfs:', RDFS, 1)
                obj = URI(obj)
            elif ot == 'literal':
                obj = Literal(obj)
            else:
                obj = bNode(obj)
        return Triple(subj, pred, obj)


    def getParams(self):
        """
        Returns the parameters for constructor in a tuple so that
        a similar KP can be constructed.
        """
        return self.params

    def join(self):
        """Joins to the smart space. Returns true is succesful,
        false otherwise.
        If SSA is defined, inserts information about the SSA to SIB.
        """
        if not self.joined:
            try:
                print 'joining', self.params
                self.joined = self.node.join(self.sspace)
            except socket.error:
                print 'socket error'
                return False
            except SIBError:
                # probably wrong SSAP format
                try:
                    self.node = self.ribsnode
                    self.sspace = self.ribssspace
                    self.ribsused = True
                    self.joined = self.node.join(self.sspace)
                except socket.error:
                    print 'RIBS socket error'
                    return False
            if self.ssa != None and self.joined:
                import uris #needed only for visualization
                tlist = [
                    ((self.node_id, uris.type, uris.kp), 'uri', 'uri'),
                    ((self.ssa, uris.hasKP, self.node_id), 'uri', 'uri')
                ]
                self.insert(tlist)
            return self.joined
        return False    #already joined

    def leave(self):
        """Leaves the smart space. Returns true is succesful,
        false otherwise.
        """
        if self.joined:
            print 'KP is leaving, subscriptions:', self.subscriptions
            for s in self.subscriptions:
                self.node.CloseSubscribeTransaction(s)
            del self.subscriptions[:]

            if self.ssa != None:
                self.removeAll(self.node_id, None, None, None)
            print 'leaving node'
            self.joined = not self.node.leave(self.sspace)
            print 'Cleaned kp', self.kpnum
            return not self.joined
        return False    #not joined; can't leave

    def _createSparqlQuery(self, triples):
        '''Creates a SPARQL query string from the triples in the list.
        Parameter triples is a tuple list whose members are format
        ((subj, pred, obj), st, pt, ot) where st and ot can be "uri", "literal"
        or "var", pt can be "uri" or "var". All variables are marked as
        projection variables. The variable names must not contain '?' or '$',
        they are added by this function. Blank nodes are not supported.
        '''
        query = 'SELECT%s WHERE { %s}'
        patterns = ''
        variables = ''
        for tr in triples:
            (s, p, o), st, pt, ot = tr
            if st == 'var':
                s = '?' + s
                variables +=  ' ' + s
            elif st == 'uri' or st == 'URI':
                s = '<' + s + '>'
            elif st == 'literal':
                s = '"' + s + '"'
            else:
                print 'Error invalid subject type!'
                return []
            if pt == 'var':
                p = '?' + p
                variables +=  ' ' + p
            elif pt == 'uri' or pt == 'URI':
                p = '<' + p + '>'
            else:
                print 'Error invalid predicate type!'
                return []
            if ot == 'var':
                o = '?' + o
                variables +=  ' ' + o
            elif ot == 'uri' or ot == 'URI':
                o = '<' + o + '>'
            elif ot == 'literal':
                o = '"' + o + '"'
            else:
                print 'Error invalid object type!'
                return []
            patterns += s + ' ' + p + ' ' + o + ' . '
        query = query % (variables, patterns)
        return query

    def query(self, s, p, o, ot):
        '''
        A template query
        '''
        print 'query', self.joined
        if self.joined:
            triple = self.toTriple(s, p, o, ot=ot)
            q = self.node.CreateQueryTransaction(self.sspace)
            results = q.rdf_query(triple)
            self.node.CloseQueryTransaction(q)
            return results
        else:
            return []

    def query_old(self, s, p, o, ot):
        '''
        Old API compatible template query
        '''
        triples = self.query(s, p, o, ot)
        results = []
        for tr in triples:
            s, p, o = tr
            o.nodetype = o.nodetype.lower()
            results.append(((s.value, p.value, o.value), o.nodetype))
        return results

    def querySparql(self, query):
        '''Makes a SPARQL Select query. The whole query must be given
        as a parameter. Returns tuple (variables, bindings) in which
        variables contains names of variables in a list and bindings
        is a list of result binding lists. Every binding list contains
        URI, Literal or bNode objects which are bound to the variables
        with same index (the order is same in variables and binding lists.
        Variable names occur only in the variables list.
        '''
        if self.joined:
            q = self.node.CreateQueryTransaction(self.sspace)
            results = q.sparql_query(query)
            self.node.CloseQueryTransaction(q)
            return results
        else:
            return []
        
    def querySparql_list(self, triples):
        '''Creates a SPARQL Select query and uses querySparql function to
        execute it. Uses _createSparqlQuery function to generate the query
        string.
        '''
        query = self._createSparqlQuery(triples)
        return self.querySparql(query)
                

    def queryWqlValues(self, frame, body):
        """Creates a WQL Values query, makes it and closes it.
        Returns the result. The result is a list that contains tuples
        (node, literal?).
        """
#        if self.joined:
#            q = self.node.CreateQueryTransaction(self.sspace)
#            results = q.wql_values_query((frame, False), body)
#            self.node.CloseQueryTransaction(q)
#            return results
#        else:
#            return []
        print 'Not implemented!'
        return []


    def queryWqlRelated(self, node1, node2, path):
        """
        Creates a WQL related query and returns the result. Checks if node2
        is reachable from node1 via path. Returns true or false.
        """
#        if self.joined:
#            q = self.node.CreateQueryTransaction(self.sspace)
#            res = q.wql_related_query((node1, False), (node2, False), path)
#            self.node.CloseQueryTransaction(q)
#            return res
#        else:
#            return False
        print 'Not implemented!'
        return []


    def queryWqlIstype(self, node, type):
        """
        Creates a WQL istype query and returns the result. Checks if node is
        an instance of type. Returns true or false.
        The parameters must be uris as strings, not tuples.
        """
#        if self.joined:
#            q = self.node.CreateQueryTransaction(self.sspace)
#            res = q.wql_istype_query((node, False), (type, False))
#            self.node.CloseQueryTransaction(q)
#            return res
#        else:
#            return False
        print 'Not implemented!'
        return []

    def queryWqlIssubtype(self, subtype, supertype):
        """
        Creates a WQL istype query and returns the result. Checks if subtype is
        a subclass of supertype. Returns true or false.
        The parameters must be uris as strings, not tuples.
        """
#        if self.joined:
#            q = self.node.CreateQueryTransaction(self.sspace)
#            res = q.wql_issubtype_query((subtype, False), (supertype, False))
#            self.node.CloseQueryTransaction(q)
#            return res
#        else:
#            return False
        print 'Not implemented!'
        return []

    def queryWqlNodetypes(self, node):
#        if self.joined:
#            q = self.node.CreateQueryTransaction(self.sspace)
#            res = q.wql_nodetypes_query((node, False))
#            self.node.CloseQueryTransaction(q)
#            return res
#        else:
#            return ""
        print 'Not implemented!'
        return []

    def queryObjects(self, subject, predicate):
        """
        Queries all objects in triples with given subject and predicate.
        Uses rdf (triple) query.
        Returns URI, Literal or bNode objects in a list.
        """
        objects = []
        results = self.query(subject, predicate, None, 'uri')
        for triple in results:
            objects.append(triple[2])
        return objects

    def queryObjects_old(self, subject, predicate):
        """
        Queries all objects in triples with given subject and predicate.
        Uses rdf (triple) query.
        Returns uris of objects in a list.
        """
        objects = []
        results = self.query(subject, predicate, None, 'uri')
        for triple in results:
            objects.append(triple[2].value)
        return objects

    def queryWqlObjects(self, subject, predicate):
        """
        Queries all objects in triples with given subject and predicate.
        Uses WQL query.
        Returns uris of objects in a list.
        """
#        objects = []
#        results = self.queryWqlValues(subject, ['seq', predicate])
#        for obj, lit in results:
#            objects.append(obj)
#        return objects
        print 'Not implemented!'
        return []


#    def queryObject(self, subject, predicate):
#        """Creates a Wilbur query with given subject and predicate and makes
#        the query. Returns the first resulting object.
#        It is assumed that there is exactly one result.
#        If there is no result, an empty string is returned.
#        The Wilbur query takes also the superproperties of the predicate
#        into account.
#        """
#        results = self.queryWqlValues(subject, ['seq', predicate])
#        if len(results) > 0:
#            return results[0][0]
#        return ""

    def queryObject(self, subject, predicate):
        """Creates a template query with given subject and predicate and makes
        the query. Returns the first resulting URI or Literal object.
        It is assumed that there is exactly one result.
        If there is no result, None is returned.
        """
        results = self.queryObjects(subject, predicate)
        if len(results) > 0:
            return results[0]
        return None

    def queryObject_old(self, subject, predicate):
        """Creates a template query with given subject and predicate and makes
        the query. Returns the first resulting object's URI or literal value.
        It is assumed that there is exactly one result.
        If there is no result, an empty string is returned.
        """
        results = self.queryObjects_old(subject, predicate)
        if len(results) > 0:
            return results[0]
        return ""

    def insertTriple(self, s, p, o, st, ot):
        """
        A convenience method which uses the method with tripleList parameter.
        """
        tripleList = [((s, p, o), st, ot)]
#        triple = self.toTriple(s, p, o, st, ot)
#        tripleList = [triple]
        return self.insert_old(tripleList)

    def insert(self, tripleList):
        """
        Creates an insert transaction with given triple list.
        Returns the result tuple which contains status and a
        dictionary which contains the uris of blank nodes.
        In case of RIBS inserts the dict is empty.
        The tripleList param must be list of Triple objects.
        """
        if self.joined:
            trans = self.node.CreateInsertTransaction(self.sspace)
            results = trans.send(tripleList)
            self.node.CloseInsertTransaction(trans)
            return results
        else:
            return []

    def insert_old(self, triples):
        """
        Creates an update transaction with given removed and inserted triples.
        Uses 'rdf-m3' encoding. Returns whatever the SIB answers.
        The parameters are lists ((subject, predicate, object), stype, otype).
        Also substitutes occurrences of 'rdf:type' with tho full URI
        http://www.w3.org/1999/02/22-rdf-syntax-ns#type.
        """
        itriples = []
        for tr in triples:
            (s,p,o),st,ot = tr
            itriples.append(self.toTriple(s, p, o, st, ot))
        return self.insert(itriples)

    def removeAllFrom(self, subject):
        """
        Removes all triples whose subject is the given uri.
        A convenience function that uses removeAll().
        """
        self.removeAll(subject, None, None, 'uri')


    def removeAll(self, s, p, o, ot):
        """
        Queries for all triples matching the specified triple which
        may contain wildcards and removes them.
        """
        r_triples = self.query(s, p, o, ot)
        self.remove(r_triples)

    def removeTriple(self, s, p, o, ot):
        """
        Removes the given triple. The triple
        cannot contain wildcards.
        A convenience function that uses the remove function.
        """
        triple = self.toTriple(s, p, o, ot=ot)
        tripleList = [triple]
        self.remove(tripleList)

    def remove(self, list):
        """
        Removes the given triple list. The triples
        cannot contain wildcards.
        The list must be set of Triple objects.
        """
        if self.joined:
            trans = self.node.CreateRemoveTransaction(self.sspace)
            trans.remove(list)
            self.node.CloseRemoveTransaction(trans)

    def remove_old(self, triples):
        """
        Creates an update transaction with given removed and inserted triples.
        Uses 'rdf-m3' encoding. Returns whatever the SIB answers.
        The parameters are lists ((subject, predicate, object), stype, otype).
        """
        tr = []
        for (s,p,o),st,ot in triples:
            tr.append(self.toTriple(s, p, o, st, ot))
        return self.remove(tr)

    def update(self, i_triples, r_triples):
        """
        Creates an update transaction with given removed and inserted triples.
        Uses 'rdf-m3' encoding. Returns whatever the SIB answers.
        The parameters must be lists of Triple objects.
        """
        if self.joined:
            if self.ribsused:
                # RIBS update can be used if there is one inserted triple
                # with literal object and no removed triples
                # Otherwise use remove+insert
                if len(r_triples) == 0 and len(i_triples) == 1 and \
                        i_triples[0][2].nodetype == 'literal':
                    print 'RIBS update!'
                    # works similarly to SM3 update
                else:
                    print 'Remove+insert'
                    results = []
                    if len(r_triples) > 0:
                        results = self.remove(r_triples)
                    if len(i_triples) > 0:
                        results = self.insert(i_triples)
                    return results
            trans = self.node.CreateUpdateTransaction(self.sspace)
            #currently confirm MUST be True because of a bug in SIB implementation
            results = trans.update(i_triples, 'rdf-m3', r_triples, 'rdf-m3', True)
            self.node.CloseUpdateTransaction(trans)
            return results
        else:
            return []

    def update_old(self, i_triples, r_triples):
        """
        Creates an update transaction with given removed and inserted triples.
        Uses 'rdf-m3' encoding. Returns whatever the SIB answers.
        The parameters are lists ((subject, predicate, object), stype, otype).
        """
        itr = []
        rtr = []
        for (s,p,o),st,ot in i_triples:
            itr.append(self.toTriple(s, p, o, st, ot))
        for (s,p,o),st,ot in r_triples:
            rtr.append(self.toTriple(s, p, o, st, ot))
        return self.update(itr, rtr)

    def updateObject(self, s, p, o, ot):
        """
        Performs an update transaction which changes the current object to the
        given object. First queries everything with given subject and predicate
        and then makes an update with them as removed triples.

        If there are currently no triples with given subject and predicate
        in the SIB, makes a normal insert transaction.

        """
        r_tr = []
        triple = self.toTriple(s, p, o, ot=ot)
        i_tr = [triple]
        old = self.queryObjects(s, p)
        if len(old) > 0:
            for ob in old:
                if ob.value != o:
                    r_tr.append(Triple(triple[0], triple[1], ob))
            if len(r_tr) == 0:
                # The object has already been there: nothing to do
                return []
            return self.update(i_tr, r_tr)
        else:
            # No old values
            return self.insert(i_tr)

    def subscribe_list(self, triples, handler, param=None):
        '''Creates a subscribe transaction from old-style list.
        List items are of form (s, p, o), ot).
        '''
        if self.joined:
            trlist = []
            for triple in triples:
                (s, p, o), ot = triple
                trlist.append(self.toTriple(s, p, o, ot=ot))
            trans = self.node.CreateSubscribeTransaction(self.sspace)
            results = trans.subscribe_rdf(trlist, Handler(handler, param))
            self.subscriptions.append(trans)
            return results, trans
        else:
            return [], None

    def subscribe(self, s, p, o, ot, handler, param=None):
        """
        Creates a subscribe transaction with given triple.
        Note that handler parameter is a method or a function, not an object.
        This method wraps the method in an object and delivers the object
        as a parameter.
        """
        if self.joined:
            triple = self.toTriple(s, p, o, ot=ot)
            trlist = [triple]
            trans = self.node.CreateSubscribeTransaction(self.sspace)
            results = trans.subscribe_rdf(trlist, Handler(handler, param))
            self.subscriptions.append(trans)
            return results, trans
        else:
            return [], None

    def subscribeObject(self, s, p, handler, param=None):
        return self.subscribe(s, p, None, 'uri', handler, param)

    def subscribeSparql(self, query, handler, param=None):
        '''Creates a SPARQL Subscribe. The SIB must have support for this.
        Initial results are returned in a similar way as in querySparql
        and new results are given as parameters to handler function.
        The parameters are variables and bindings as in querySparql.
        '''
        if self.joined:
            trans = self.node.CreateSubscribeTransaction(self.sspace)
            results = trans.subscribe_sparql(query, Handler(handler, param))
            self.subscriptions.append(trans)
            return results, trans
        else:
            return [], None

    def subscribeSparql_list(self, triples, handler, param=None):
        '''Creates a SPARQL subscribe from the list. Syntax is
        similar as in querySparql_list and behaviour is similar
        as in subscribeSparql.
        '''
        query = self._createSparqlQuery(triples)
        return self.subscribeSparql(query, handler, param)


    def subscribeWqlValues(self, frame, body, handler, param=None):
        """Creates a WQL Values subscription and makes it.
        The frame is just a uri, not a tuple.
        Returns the result and transaction as a tuple.
        The result is a list that contains tuples (node, literal?).
        """
#        if self.joined:
#            trans = self.node.CreateSubscribeTransaction(self.sspace)
#            results = trans.subscribe_wql_values((frame, False),
#                                        body, Handler(handler, param))
#            self.subscriptions.append(trans)
#            return results, trans
#        else:
#            return [], None
        print 'Not implemented!'
        return [], None


    def subscribeWqlObject(self, s, p, handler, param=None):
        return self.subscribeWqlValues(s, ['seq', p], handler, param)

    def subscribeWqlRelated(self, node1, node2, path, handler, param):
        """Creates a WQL related subscription and makes it.
        The format is similar to the related query.
        """
#        if self.joined:
#            trans = self.node.CreateSubscribeTransaction(self.sspace)
#            res = trans.subscribe_wql_related((node1, False), (node2, False),
#                    path, Handler(handler, param))
#            self.subscriptions.append(trans)
#            return res, trans
#        else:
#            return [], None
        print 'Not implemented!'
        return [], None

    def closeSubscription(self, subs):
        if subs in self.subscriptions:
            self.subscriptions.remove(subs)
        self.node.CloseSubscribeTransaction(subs)


class Handler:
    """
    This class makes it possible to define a method for subscription callbacks.
    Subscribe transaction requires an object that has a method named handle.
    This class has such method, which just calls a method given in the
    constructor of the object. There is also a possibility to define
    an extra parameter for the method.
    """
    def __init__(self, method, param=None):
        self.method = method
        self.param = param


    def handle(self, added, removed):
        if self.param == None:
            self.method(added, removed)
        else:
            self.method(added, removed, self.param)


