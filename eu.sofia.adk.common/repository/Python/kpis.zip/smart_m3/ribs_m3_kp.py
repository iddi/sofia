import sys

import m3_kp
from m3_kp import KP, Insert, Remove, Query, Update, Subscribe, Transaction
from m3_kp import NodeM3RDFHandler, SSAPMsgHandler, bNode, URI, Literal
from m3_kp import SIBError, Triple, TCPConnector, RDFSubscribeHandler
from m3_kp import parse_M3RDF, M3_SIB_ERROR

from StringIO import StringIO
from xml.sax import make_parser
import threading

END_TAG = '</M>'
ETL = 4 # Length of end tag string

CURRENT_TR_ID = 1

SIB_ANY_URI = 'rdf:nil '
SSAP_MESSAGE_TEMPLATE = \
    '''<M    F="WM"  T="%s">   <N> %4.4s</N>'''\
    '''<S> %4.4s</S><T> %04.4d</T>%s</M>'''

SSAP_JOIN_PARAM_TEMPLATE = '<C> %4.4s</C>'

SSAP_INSERT_PARAM_TEMPLATE = \
        '''<E> RDF/WAX1</E><G> <L   I="%03.3d">   %s</L></G>'''

SSAP_REMOVE_PARAM_TEMPLATE = SSAP_INSERT_PARAM_TEMPLATE

SSAP_UPDATE_PARAM_TEMPLATE = \
        '''<E> RDF/WAX1</E><G> <L   I="%03.3d">   %s</L></G>'''\
        '''<G> <L   I="%03.3d">   %s</L></G>'''

SSAP_QUERY_TEMPLATE = \
        '''<Q    T="W3">   <G> <L   I="%03.3d">   %s</L></G></Q>'''

SSAP_SPARQL_QUERY_TEMPLATE = '''<Q    T="S1">   %s</Q>'''

SSAP_UNSUBSCRIBE_TEMPLATE = '<O> %s</O>'

M3_TRIPLE_TEMPLATE = \
        '''<t> <%(st)s> %(s)s</%(st)s><%(pt)s> %(p)s</%(pt)s><%(ot)s> %(o)s</%(ot)s></t>'''

def get_tr_id():
    '''Modified from m3_kp.py so that does not contain more
    than four digits.
    '''
    global CURRENT_TR_ID
    rv = CURRENT_TR_ID
    CURRENT_TR_ID = CURRENT_TR_ID + 1
    return rv % 1000

def parse_SPARQLWAX(results):
    variables = []
    bindings = []
    parser = make_parser()
    mh = RIBS_SPARQLHandler(variables, bindings)
    parser.setContentHandler(mh)
    parser.parse(StringIO(results.encode('utf-8')))
    return (variables, bindings)

def parse_M3RDF(results):
    results_list = []
    parser = make_parser()
    mh = RIBS_NodeM3RDFHandler(results_list, {})
    parser.setContentHandler(mh)
    parser.parse(StringIO(results.encode('utf-8')))
    return results_list


class RIBS_KP(KP):
    def __init__(self, node_id):
        KP.__init__(self, node_id)
        self.conns = dict()
        self.handlers = dict()

    def join(self, dest):
        '''Join a smart space. Argument dest is a smart space handle of form
        (SSName, (connector class, (connector constructor args))).
        join() accepts handles returned by discover() method.
        Returns True if succesful, False otherwise.
        '''
        dest = self.getTransactionParams(dest)
        targetSS, conn = dest

        tr_id = get_tr_id()
        tmp = [SSAP_MESSAGE_TEMPLATE % ("JR", str(self.node_id),
                                      str(targetSS), tr_id,
                                      SSAP_JOIN_PARAM_TEMPLATE % ("XYZY"))]
        join_msg = "".join(tmp)

        conn.connect()
        conn.send(join_msg)
        cnf = conn.receive()
        print 'join', join_msg
        print 'conf', cnf
        conn.close()
        if "status" in cnf and cnf["status"] == m3_kp.M3_SUCCESS:
            self.member_of.append(targetSS)
            return True
        elif "status" in cnf:
            raise SIBError(cnf["status"])
        else:
            raise SIBError(m3_kp.M3_SIB_ERROR)
    
    def leave(self, dest):
        '''Leave a smart space. Argument dest is a smart space handle of form
        (SSName, (connector class, (connector constructor args))).
        leave() accepts handles returned by discover() method.
        Returns True if succesful, False otherwise.
        '''
        rkey = dest
        dest = self.getTransactionParams(dest)
        targetSS, conn = dest

        tr_id = get_tr_id()

        leave_msg = SSAP_MESSAGE_TEMPLATE % ("LR", str(self.node_id),
                                                 str(targetSS), tr_id, "")
        conn.connect()
        print 'sending'
        conn.send(leave_msg)
        cnf = conn.receive()
        conn.close()
        conn.leave()  # closes the connection
        # discards connection and subscribe handler
        self.removeTransactionParams(rkey)
        if "status" in cnf and cnf["status"] == m3_kp.M3_SUCCESS:
            tmp = filter(lambda x: x != targetSS, self.member_of)
            self.member_of = tmp
            return True
        elif "status" in cnf:
            tmp = filter(lambda x: x != targetSS, self.member_of)
            self.member_of = tmp
            raise SIBError(cnf["status"])
        else:
            print 'errcnf', cnf, conn
            tmp = filter(lambda x: x != targetSS, self.member_of)
            self.member_of = tmp
            raise SIBError(m3_kp.M3_SIB_ERROR)

    def getTransactionParams(self, dest, subscribe=False):
        '''Changes m3_kp style params to ribs_m3_kp params.'''
        targetSS, handle = dest
        connector, args = handle
        if dest in self.conns:
            conn = self.conns[dest]
        else:
            conn = connector(args)
            self.conns[dest] = conn
        if subscribe:
            if dest in self.handlers:
                handler = self.handlers[dest]
            else:
                sconn = connector(args)
                handler = RIBS_RDFSubscribeHandler(self.node_id, sconn)
                self.handlers[dest] = handler
            return (targetSS, (conn, handler))    
        return (targetSS, conn)

    def removeTransactionParams(self, dest):
        if dest in self.conns:
            del self.conns[dest]
        if dest in self.handlers:
            del self.handlers[dest]


    def CreateInsertTransaction(self, dest):
        '''Creates an insert transaction for inserting information
        to a smart space.
        Returns an instance of Insert(Transaction) class
        '''
        dest = self.getTransactionParams(dest)
        c = RIBS_Insert(dest, self.node_id)
        self.connections.append(("PROACTIVE", c))
        return c

    def CreateRemoveTransaction(self, dest):
        '''Creates a remove transaction for removing information
        from a smart space.
        Returns an instance of Remove(Transaction) class
        '''
        dest = self.getTransactionParams(dest)
        c = RIBS_Remove(dest, self.node_id)
        self.connections.append(("RETRACTION", c))
        return c

    def CreateUpdateTransaction(self, dest):
        dest = self.getTransactionParams(dest)
        c = RIBS_Update(dest, self.node_id)
        self.connections.append(("UPDATE", c))
        return c

    def CreateSubscribeTransaction(self, dest, once = False):
        '''Creates a subscribe transaction for subscribing to
        information in a smart space.
        Returns an instance of Subscribe(Transaction) class
        '''
        dest = self.getTransactionParams(dest, True)
        c = RIBS_Subscribe(dest, self.node_id, once)
        self.connections.append(("REACTIVE", c))
        return c

    def CreateQueryTransaction(self, dest):
        '''Creates a query transaction for querying information
        in a smart space.
        Returns an instance of Query(Transaction) class
        '''
        dest = self.getTransactionParams(dest)
        c = RIBS_Query(dest, self.node_id)
        self.connections.append(("QUERY", c))
        return c

class RIBS_Transaction(Transaction):
    '''Abstract base class for M3 operations.
    '''
    def __init__(self, dest, node_id):
        '''Same as in superclass but no Connector instance created'''
        self.node_id = node_id
        self.tr_id = ""
        self.targetSS, self.conn = dest

    def _nodetype_tag(self, ntype):
        '''Returns nodetype tag character 'u', 'b' or 'l'.'''
        if ntype == 'URI':
            return 'u'
        elif ntype == 'bnode':
            return 'b'
        else:
            return 'l'

    def _get_wax_value(self, node):
        value = str(node.value)
        while len(value) % 4 > 0 or len(value) < 8:
            value += ' '
        return value

    def _encode(self, triples, wildcard = True):
        tmp = []
        for t in triples:
            s, p, o = t
            if wildcard:
                if s == None:
                    s = URI(SIB_ANY_URI)
                if p == None:
                    p = URI(SIB_ANY_URI)
                if o == None:
                    o = URI(SIB_ANY_URI)

            st = self._nodetype_tag(s.nodetype)
            pt = self._nodetype_tag(p.nodetype)
            ot = self._nodetype_tag(o.nodetype)

            tmp.append(M3_TRIPLE_TEMPLATE % \
                        {'st': st, 's': self._get_wax_value(s),
                        'pt': pt, 'p': self._get_wax_value(p),
                        'ot': ot, 'o': self._get_wax_value(o)})
        return "".join(tmp)

class RIBS_Insert(RIBS_Transaction, Insert):
    '''Class handling Insert transactions.
    '''
    def _create_msg(self, tr_id, payload, confirm, encoding):
        '''Internal. Create a SSAP XML message for INSERT REQUEST
        '''
        if tr_id > 1000:
            tr_id %= 1000
        params = SSAP_INSERT_PARAM_TEMPLATE % (len(payload)/4+4,
                                                   payload)
        tmp = SSAP_MESSAGE_TEMPLATE % ("IR", str(self.node_id),
                                           str(self.targetSS),
                                           tr_id, params)
        return tmp

    def send(self, payload, pl_type = "python",
             encoding = "rdf-m3", confirm = True):
        '''Accepted format for payload is determined by the parameter pl_type.
           - pl_type == 'python': payload is a list of Triple instances

           - pl_type != 'python': payload is given in encoded form,
             either rdf-xml or rdf-m3. The encoding parameter has to be
             set accordingly.

             If confirmation is requested, the return value will be a
             dictionary associating named blank nodes in the insert graph
             to the actual URIs stored in the SIB (works for rdf-m3
             encoding only)

             SOME CHANGES TO SUPERCLASS METHOD:
             - urns received instead of bnodes, they are parsed
             - if less urns received than triples sent, resend the rest
        '''
        if pl_type == 'python':
            encoding = 'rdf-wax1'

        self.tr_id = get_tr_id()
        len_triples = None
        if pl_type == "python":
            if not isinstance(payload, list):
                payload = [payload]
            payload_enc = self._encode(payload, wildcard = False)
            len_triples = len(payload)
        else:
            payload_enc = payload
        xml_msg = self._create_msg(self.tr_id,
                                   payload_enc,
                                   confirm,
                                   encoding)
        self.conn.connect()
        self.conn.send(xml_msg)
        if confirm:
            rcvd = self.conn.receive()
            self._check_error(rcvd)
            if encoding.lower() == 'rdf-wax1':
                urns = []
                icf = RIBS_URNHandler(urns)
                parser = make_parser()
                parser.setContentHandler(icf)
                try:
                    parser.parse(StringIO(rcvd['results']))
                except:
                    print 'Error:'
                    print rcvd, xml_msg
                if len_triples != None and len(urns) < len_triples:
                    print 'triples:', len_triples, 'urns:', len(urns)
                    print payload
                    # re-insert triples that did not succeed
                    # recursive
                    i = len(urns)
                    while i < len_triples:
                        # RIBS supports at most len(urns) inserts
                        # i + len(urns) can be > len_triples,
                        # does not matter here
                        pl = payload[i:i+len(urns)]
                        ret = self.send(pl, pl_type, encoding, confirm)
                        urns.extend(ret[1])
                        i += len(urns)
                return (rcvd["status"], urns)
            else:
                return (rcvd["status"], [])

class RIBS_Remove(RIBS_Transaction, Remove):
    '''Class for handling Remove transactions.
    '''
    def _create_msg(self, tr_id, triples, type, confirm):
        '''Internal. Create a SSAP XML message for REMOVE REQUEST
        '''
        if tr_id > 1000:
            tr_id %= 1000
        params = SSAP_REMOVE_PARAM_TEMPLATE % (len(triples)/4+4, triples)
        tmp = SSAP_MESSAGE_TEMPLATE % ("RR", str(self.node_id),
                                           str(self.targetSS),
                                           tr_id, params)
        return tmp

class RIBS_Update(RIBS_Transaction, Update):
    def _create_msg(self, tr_id, i_triples, i_type, r_triples, r_type, confirm):
        '''Internal. Create a SSAP message for UPDATE REQUEST.
        Note that in WAX removed triples come before inserted.
        '''
        if tr_id > 1000:
            tr_id %= 1000
        params = SSAP_UPDATE_PARAM_TEMPLATE % (len(r_triples)/4+4, r_triples,
                                               len(i_triples)/4+4, i_triples)
        tmp = SSAP_MESSAGE_TEMPLATE % ("UR", str(self.node_id),
                                           str(self.targetSS),
                                           tr_id, params)
        return tmp

    def update(self, i_triples, i_enc,
               r_triples, r_enc, confirm = True):
        '''Forces encoding parameters be different from rdf-m3.'''
        return Update.update(self, i_triples, "rdf-wax1",
                             r_triples, "rdf-wax1", confirm)

class RIBS_Query(RIBS_Transaction, Query):
    def _create_rdf_msg(self, tr_id, triples):
        if tr_id > 1000:
            tr_id %= 1000
        triples = self._encode(triples)
        params = SSAP_QUERY_TEMPLATE % (len(triples)/4+4, triples)
        msg = SSAP_MESSAGE_TEMPLATE % ("QR", str(self.node_id),
                                           str(self.targetSS),
                                           tr_id, params)
        return msg
    
#    def rdf_query(self, triples):
#        oldnh = m3_kp.NodeM3RDFHandler
#        m3_kp.NodeM3RDFHandler = RIBS_NodeM3RDFHandler
#        ret = Query.rdf_query(self, triples)
#        m3_kp.NodeM3RDFHandler = oldnh
#        return ret

    def rdf_query(self, triples):
        '''Identical to superclass's, which uses own module's function.'''
        if type(triples) != list:
            triples = [triples]
        self.tr_id = get_tr_id()
        xml_msg = self._create_rdf_msg(self.tr_id, triples)
        self.conn.connect()
        self.conn.send(xml_msg)
        response = self.conn.receive()
        self._check_error(response)
        print 'received', response
        if "results" in response:
            triple_list = parse_M3RDF(response["results"])
            return triple_list
        else:
            raise SIBError(M3_SIB_ERROR)

    def sparql_query(self, query):
        while len(query) % 4 > 0:
            query += ' '
        params = SSAP_SPARQL_QUERY_TEMPLATE % (query)
        msg = SSAP_MESSAGE_TEMPLATE % ("QR", str(self.node_id),
                                           str(self.targetSS),
                                           get_tr_id(), params)
        self.conn.connect()
        print 'SPARQL QUERY:', msg
        self.conn.send(msg)
        response = self.conn.receive()
        self._check_error(response)
        if "P" in response: #SPARQL start tag
            ret = parse_SPARQLWAX(response["P"])
            return ret
        else:
            raise SIBError(M3_SIB_ERROR)

class RIBS_Subscribe(RIBS_Transaction, Subscribe):
    def __init__(self, dest, node_id, once = False):
        '''Same as in superclass but no Connector instances created'''
        self.node_id = node_id
        self.tr_id = 0
        # handler is RIBS_RDFSubscribeHandler Thread object,
        # all indications are in same thread
        self.targetSS, (self.conn, self.handler) = dest
        self.once = once
        self.tr_type = "SUBSCRIBE"
        
    def _create_rdf_msg(self, tr_id, triples):
        if tr_id > 1000:
            tr_id %= 1000
        triples = self._encode(triples)
        params = SSAP_QUERY_TEMPLATE % (len(triples)/4+4, triples)
        msg = SSAP_MESSAGE_TEMPLATE % ("SR", str(self.node_id),
                                           str(self.targetSS),
                                           tr_id, params)
        return msg

    def subscribe_rdf(self, triple, msg_handler):
        '''Changed from superclass so that
        1) Subscription and unsubscription are done through main socket
        2) One handler thread is used to receive all indications
        '''       
        if type(triple) != list:
            triple = [triple]
        self.msg_handler = msg_handler
        self.tr_id = get_tr_id()
        xml_msg = self._create_rdf_msg(self.tr_id, triple)
        # subscription must be made using message handler's socket
        cnf = self.handler.createSubscription(xml_msg)
        self._check_error(cnf)

        self.sub_id = cnf["subscription_id"]
        self.handler.add_msg_handler(self.sub_id, msg_handler)
        initial_result = parse_M3RDF(cnf["results"])

        return initial_result

    def subscribe_sparql(self, query, msg_handler):
        '''EXPERIMENTAL'''
        self.msg_handler = msg_handler
        while len(query) % 4 > 0:
            query += ' '
        params = SSAP_SPARQL_QUERY_TEMPLATE % (query)
        msg = SSAP_MESSAGE_TEMPLATE % ("SR", str(self.node_id),
                                           str(self.targetSS),
                                           get_tr_id(), params)
        # subscription must be made using message handler's socket
        cnf = self.handler.createSubscription(msg)
        self._check_error(cnf)

        self.sub_id = cnf["subscription_id"]
        self.handler.add_msg_handler(self.sub_id, msg_handler)

        if "P" in cnf: #SPARQL start tag
            ret = parse_SPARQLWAX(cnf["P"])
            return ret
        else:
            raise SIBError(M3_SIB_ERROR)
        

    def close(self):
        '''Closes the subscription using handler socket.'''
        tmp = SSAP_UNSUBSCRIBE_TEMPLATE % (self.sub_id)
        msg = SSAP_MESSAGE_TEMPLATE % ("uR", str(self.node_id),
                                           str(self.targetSS),
                                           get_tr_id(), tmp)
        self.handler.closeSubscription(self.sub_id, msg)

class RIBS_RDFSubscribeHandler(RDFSubscribeHandler):
    def __init__(self, node_id, connector):
        '''This object handles all subscribe indications, tr_id and msg_handler
        parameters of superclass are not used.
        '''
        RDFSubscribeHandler.__init__(self, node_id, 0, connector, 0)
        self.msg_handlers = dict()
        self.running = False
        # lock for modifying msg handlers
        self.lock = threading.Lock()
        # condition variable for creating subscriptions
        self.cv = threading.Condition()
        self.cnf = None
        # condition variable for subscribe ids (must be saved for closing)
#        self.idcv = threading.Condition()
#        self.subid = None

    def createSubscription(self, msg):
        '''Sends the message and returns the response.
        Because the response is received in another thread, waits until it is
        ready.
        '''
        print 'create subs'
        self.conn.connect()
        if not self.running:
            self.running = True
            self.start()
        self.conn.send(msg)
        print 'acq'
        self.cv.acquire()
        while self.cnf == None:
            print 'wait'
            self.cv.wait()
        ret = self.cnf
        self.cnf = None
        self.cv.release()
        print 'rel'
        return ret

    def closeSubscription(self, subid, msg):
        '''Closes a subscription.
        The receiver loop will remove handler when it receives confirmation.
        '''
        print 'closing'
#        self.idcv.acquire()
#        # wait until previous unsubscribe has been confirmed
#        while self.subid:
#            self.idcv.wait()
#        self.subid = subid
#        self.idcv.release()
#        print 'subid set', subid
        self.conn.send(msg)
        self.remove_msg_handler(subid) 
        print 'sent', msg

    def add_msg_handler(self, subid, handler):
        self.lock.acquire()
        self.msg_handlers[subid] = handler
        self.lock.release()

    def remove_msg_handler(self, subid):
        '''Removes a msg handler.
        If it is last one, closes the socket.
        '''
        ret = False
        print 'rem'
        self.lock.acquire()
        print self.msg_handlers, subid
        if subid in self.msg_handlers:
            del self.msg_handlers[subid]
            # connection is closed when there are no subscriptions
            if len(self.msg_handlers) == 0:
                self.running = False
                ret = True
        self.lock.release()
        if ret:
            print 'removing subs'
            self.conn.leave()
        return ret

    def run(self):
        '''Modified so that msg_handler is chosen according to the subscribe id.
        '''
        while self.running:
            msg = self.conn.receive()
            print 'subsrec', len(msg), 'fields'
            if not self.running:
                # empty msg
                break
            elif len(msg) == 0:
                continue
            try:
                if msg["transaction_type"] == "SUBSCRIBE":
                    if msg["message_type"] == "INDICATION":
                        subid = msg['subscription_id']
                        handler = None
                        self.lock.acquire()
                        if subid in self.msg_handlers:
                            handler = self.msg_handlers[subid]
                        self.lock.release()
                        if handler:
                            # start the handler in own thread to prevent
                            # deadlocks caused by calling subscribe in handler
                            if 'P' in msg:
                                # SPARQL subscribe indication
                                # note different meaning of parameters
                                var, bind = parse_SPARQLWAX(msg["P"])
                                args = (var, bind)
                            else:
                                added_list = parse_M3RDF(msg["new_results"])
                                rem_list = parse_M3RDF(msg["obsolete_results"])
                                args = (added_list, rem_list)
                            t = threading.Thread(target=handler.handle,
                                                 args=args)
                            t.start()
                    elif msg["message_type"] == "CONFIRM":
                        self.cv.acquire()
                        self.cnf = msg
                        self.cv.notify()
                        self.cv.release()
                elif msg["transaction_type"] == "UNSUBSCRIBE":
                    if msg["message_type"] == "CONFIRM":
                        print 'UC'
#                        end = False
#                        self.lock.acquire()
#                        if len(self.msg_handlers) == 0:
#                            end = True
#                        self.lock.release()
#                        if end:
#                            return
#                        self.idcv.acquire()
#                        subid = self.subid
#                        self.subid = None
#                        self.idcv.notify()
#                        self.idcv.release()
#                        print 'None', subid
#                        if self.remove_msg_handler(subid):
#                            print 'returning'
#                            return
                    elif msg["message_type"] == "INDICATION":
                        subid = msg['subscription_id']
#                        if self.remove_msg_handler(subid):
#                            return
                else:
                    raise SIBError(M3_SIB_ERROR)
            except KeyError:
                print 'KeyError:', msg, self.conn, sys.exc_info()
                raise
        print 'MESSAGE HANDLER THREAD QUITTING NOW'

class RIBS_TCPConnector(TCPConnector):
    '''Extended so that the connection is not closed between queries.'''
    def __init__(self, arg_tuple):
        TCPConnector.__init__(self, arg_tuple)
        self.s = None
        self.lock = threading.Lock()

    def connect(self):
        if self.s == None:
            TCPConnector.connect(self)

    def send(self, msg):
        '''Same as in superclass but without shutdown'''
        length = len(msg)
        sent = self.s.send(msg)
        while sent < length:
            # If complete msg could not be sent, try to send the remaining part
            sent += self.s.send(msg[sent:])
        print 'Sent', msg

    def receive(self):
        '''This is identical to the superclass's function but must be rewritten
        because uses global variables END_TAG and ETL.
        '''
        print 'msg buffer', self.msg_buffer
        msg_end_index = self.msg_buffer.find(END_TAG)
        # Check if msg_buffer contains a complete message
        # If so, return it without receiving from network
        if msg_end_index != -1:
            msg = self.msg_buffer[:msg_end_index + ETL]
            self.msg_buffer = self.msg_buffer[msg_end_index + ETL:]
            return self._parse_msg(msg)
        msg = self.msg_buffer
        self.msg_buffer = ""
        # Different conditions cause breaking out of the loop
        # Not a perpetual while loop
        while True:
            chunk = self.s.recv(4096)
            if len(chunk) == 0: # Socket closed by SIB
                msg_end_index = msg.find(END_TAG)
                # Two cases:
                # 1: Socket was closed, no complete message
                #    -> return empty dict, discard incomplete message if any
                # 2: Socket was closed, complete message received
                #    -> return parsed message
                if msg_end_index == -1:
                    print "Socket closed with incomplete msg", msg, END_TAG
                    return {}
                else:
                    return self._parse_msg(msg)
            msg = msg + chunk
            msg_end_index = msg.find(END_TAG)
            if msg_end_index == -1: # Received partial msg
                continue
            elif msg_end_index + ETL < len(msg):
                # Received also start of next msg
                self.msg_buffer += msg[msg_end_index + ETL:]
                return self._parse_msg(msg[:msg_end_index + ETL])
            elif msg_end_index + ETL == len(msg): # Complete msg received
                print 'Received', msg
                return self._parse_msg(msg)

    def close(self):
        '''Does nothing. The connection is closed only after leave.'''
        pass

    def leave(self):
        '''Closes the connection.'''
        print 'closing RIBS socket'
        if self.s != None:
            self.s.close()
            self.s = None

    def _parse_msg(self, msg):
#        print 'rec', msg
        parsed_msg = {}
        parser = make_parser()
        ssap_mh = RIBS_SSAPMsgHandler(parsed_msg)
        parser.setContentHandler(ssap_mh)
        try:
            parser.parse(StringIO(msg))
        except:
            print 'parse error', msg
        return parsed_msg
           
class RIBS_NodeM3RDFHandler(NodeM3RDFHandler):
    """Handler for SAX events from M3 RDF encoded triples"""
    def __init__(self, triple_list, bnodes):
        NodeM3RDFHandler.__init__(self, triple_list, bnodes)
        self.next = 's'
        self.sbnode = False
        self.pbnode = False
        self.obnode = False
        # not defined in super.__init__
        self.subject = ''
        self.predicate = ''
        self.object = ''

    def startElement(self, name, attrs):
        if self.next == 's':
            self.inSubject = True
            self.subject = ""
            if name == 'b':
                self.sbnode = True
            return
        elif self.next == 'p':
            self.inPredicate = True
            self.predicate = ""
            if name == 'b':
                self.pbnode = True
            return
        elif self.next == 'o':
            self.inObject = True
            self.object = ""
            if name == "l":
                self.literal = True
            elif name == 'b':
                self.obnode = True
            return
        elif name == "t":
            self.inTriple = True
            return
            
    def endElement(self, name):
        if self.next == 's':
            self.inSubject = False
            self.next = 'p'
            return
        elif self.next == 'p':
            self.inPredicate = False
            self.next = 'o'
            return
        elif self.next == 'p':
            self.inObject = False
            self.next = ''
            return
        elif name == "t":
            self.inTriple = False
            if self.sbnode:
                s = bNode(self.subject.strip())
            else:
                s = URI(self.subject.strip())
            if self.pbnode:
                p = bNode(self.predicate.strip())
            else:
                p = URI(self.predicate.strip())
            if self.literal:
                o = Literal(self.object.strip())
            elif self.obnode:
                o = bNode(self.object.strip())
            else:
                o = URI(self.object.strip())
            self.triple_list.append(Triple(s, p, o))
            self.literal = False
            self.next = 's'
            self.sbnode = False
            self.pbnode = False
            self.obnode = False
            return

class RIBS_SPARQLHandler(NodeM3RDFHandler):
    """Handler for SAX events from M3 RDF encoded triples"""
    def __init__(self, variables, bindings):
        self.variables = variables
        self.bindings = bindings
        self.invar = False
        self.inres = False
        self.chars = ''
        self.curbind = []

    def characters(self, ch):
        self.chars += ch

    def endElement(self, name):
        if name == 'v':
            self.variables.append(self.chars.strip())
        elif name == 'u':
            self.curbind.append(URI(self.chars.strip()))
        elif name == 'l':
            self.curbind.append(Literal(self.chars.strip()))
        elif name == 'b':
            self.curbind.append(bNode(self.chars.strip()))
        elif name == 'r':
            self.bindings.append(self.curbind)
            self.curbind = []
        self.chars = ''

class RIBS_SSAPMsgHandler(SSAPMsgHandler):
    # Parser for received SSAP messages
    # Specification of different messages
    # Can be found from Smart Space wiki
    # http://swiki.nokia.com/SmartSpaces/AccessProtocol
    def __init__(self, array):
        SSAPMsgHandler.__init__(self, array)
        self.in_subscribe_indication = False
        self.newresults = False
        self.in_sparql = False

    def startElement(self, name, attrs):
        if self.in_parameter or self.in_sparql:
            self.content.append('<%s'%name)
            for i in attrs.items():
                self.content.append(' %s = "%s"'%(str(i[0]), 
                                                  str(i[1])))
            self.content.append(">")
        else:
            if name == 'M':
                t = attrs.getValue('T')
                if len(t) == 2:
                    trtype = ''
                    msgtype = ''
                    if t[0] == 'J':
                        trtype = 'JOIN'
                    elif t[0] == 'I':
                        trtype = 'INSERT'
                    elif t[0] == 'R':
                        trtype = 'REMOVE'
                    elif t[0] == 'U':
                        trtype = 'UPDATE'
                    elif t[0] == 'Q':
                        trtype = 'QUERY'
                    elif t[0] == 'S':
                        trtype = 'SUBSCRIBE'
                    elif t[0] == 'u':
                        trtype = 'UNSUBSCRIBE'
                    elif t[0] == 'L':
                        trtype = 'LEAVE'
                    if t[1] == 'R':
                        msgtype = 'REQUEST'
                    elif t[1] == 'C':
                        msgtype = 'CONFIRM'
                    elif t[1] == 'I':
                        msgtype = 'INDICATION'
                        if t[0] == 'S':
                            self.in_subscribe_indication = True
                    self.array['transaction_type'] = trtype
                    self.array['message_type'] = msgtype
            elif name == 'N':
                name = 'node_id'
            elif name == 'S':
                name = 'space_id'
            elif name == 'T':
                name = 'transaction_id'
            elif name == 's':
                name = 'status'
            elif name == 'O':
                name = 'subscription_id'
            elif name == 'L':
                self.in_parameter = True
                self.content.append('<%s>'%name)
                if self.in_subscribe_indication:
                    if self.newresults:
                        name = 'new_results'
                        self.newresults = False
                    else:
                        name = 'obsolete_results'
                        self.newresults = True
                else:
                    name = 'results'
            elif name == 'P': #SPARQL
                self.in_sparql = True
                self.content.append('<%s>'%name)
            self.stack.append(name)
            
    def endElement(self, name):
        if self.in_parameter:
            self.content.extend(["</", name, ">"])
            if name == 'L':
                self.in_parameter = False
            else:
                return
        elif self.in_sparql:
            self.content.extend(["</", name, ">"])
            if name == 'P':
                self.in_sparql = False
            else:
                return
        elif name == 'M':
            self.in_subscribe_indication = False
            self.newresults = False
        elif name == 's':
            # map status codes
            status = ''.join(self.content).strip()
            mappings = {
                'OK': m3_kp.M3_SUCCESS,
                'NR': m3_kp.M3_SIB_NOTIFICATION_RESET,
                'NC': m3_kp.M3_SIB_NOTIFICATION_CLOSING,
                'E': m3_kp.M3_SIB_ERROR,
                'EAD': m3_kp.M3_SIB_ERROR_ACCESS_DENIED,
                'FOR': m3_kp.M3_SIB_FAILURE_OUT_OF_RESOURCES,
                'FNI': m3_kp.M3_SIB_FAILURE_NOT_IMPLEMENTED,
                'KE': m3_kp.M3_KP_ERROR,
                'KER': m3_kp.M3_KP_ERROR_REQUEST,
                'KEMI': m3_kp.M3_KP_ERROR_MESSAGE_INCOMPLETE,
                'KEMS': m3_kp.M3_KP_ERROR_MESSAGE_SYNTAX,
            }
            if status in mappings:
                status = mappings[status]
            self.content = [status]
            
        self.array[self.stack.pop()] = ''.join(self.content).strip()
        self.content = []

class RIBS_URNHandler(NodeM3RDFHandler):
    """Handler for SAX events from URN triples"""
    def __init__(self, urns):
        self.chars = ''
        self.urntriples = urns
        self.triple = []

    def characters(self, ch):
        self.chars += ch

    def endElement(self, name):
        if name == 't':
            self.urntriples.append(self.triple)
            self.triple = []
        elif name == 'u':
            self.triple.append(self.chars.strip())
        self.chars = ''
