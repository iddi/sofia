from rdflib import *
from rdflib.graph import Graph
from rdflib.parser import StringInputSource

from smart_m3.m3_kp import *

def getResource(value):
	if value == None:
		return None
	elif value.startswith("http://") :
		return URI(value)
	elif value.startswith("_:") :
		return bNode(value)
	else :
		return Literal(value)


def makeTriples(data):
	result = []
	if not data.strip().endswith("."):
		data = data+"."
	store = Graph()
	sourceCode = StringInputSource(data, None)
	store.parse(sourceCode, format='n3')
	ntriples = store.serialize(format="nt")
	for s, p, o in store:
		sub = str(s)
		if not sub.startswith("http://") and ntriples.find("_:"+sub) != -1 :
			sub = "_:"+str(s)
		ob = str(o)
		if not ob.startswith("http://") and ntriples.find("_:"+ob) != -1 :
			ob = "_:"+str(o)
		result.append ( Triple( getResource(sub), getResource(p), getResource(ob) ) )
	return result
	

def insert(kp, space, s, p, o):
	transaction = kp.CreateInsertTransaction(space)
	insert = [Triple( getResource(s), getResource(p), getResource(o) )]
	transaction.send(insert, confirm = True)
	kp.CloseInsertTransaction(transaction)
	print("Insert operation done")
		
def insert2(kp, space, data):
	insert = []
	parts = data.split()
	if len(parts) == 3 :
		insert = [Triple( getResource(parts[0]), getResource(parts[1]), getResource(parts[2]) )]
	else :
		insert = makeTriples(data)
				
	transaction = kp.CreateInsertTransaction(space)
	transaction.send(insert, confirm = True)
	kp.CloseInsertTransaction(transaction)
	print("Insert operation done")

def remove(kp, space, s, p, o):
	transaction = kp.CreateRemoveTransaction(space)
	remove = [Triple( getResource(s), getResource(p), getResource(o) )]
	transaction.remove(remove, confirm = True)
	kp.CloseRemoveTransaction(transaction)
	print("Remove operation done")
	
def remove2(kp, space, data):
	remove = []
	parts = data.split()
	if len(parts) == 3 :
		remove = [Triple( getResource(parts[0]), getResource(parts[1]), getResource(parts[2]) )]
	else :
		remove = makeTriples(data)
	
	transaction = kp.CreateRemoveTransaction(space)
	transaction.remove(remove, confirm = True)
	kp.CloseRemoveTransaction(transaction)
	print("Remove operation done")

def update(kp, space, oldS, oldP, oldO, newS, newP, newO):
	transaction = kp.CreateUpdateTransaction(space)
	old = [Triple( getResource(oldS), getResource(oldP), getResource(oldO) )]
	new = [Triple( getResource(newS), getResource(newP), getResource(newO) )]
	transaction.update(new, "RDF-M3", old, "RDF-M3", confirm = True)
	kp.CloseUpdateTransaction(transaction)
	print("Update operation done")
	
def update2(kp, space, oldData, newData):
	transaction = kp.CreateUpdateTransaction(space)
	oparts = oldData.split()
	nparts = newData.split()
	old = [Triple( getResource(oparts[0]), getResource(oparts[1]), getResource(oparts[2]) )]
	new = [Triple( getResource(nparts[0]), getResource(nparts[1]), getResource(nparts[2]) )]
	transaction.update(new, "RDF-M3", old, "RDF-M3", confirm = True)
	kp.CloseUpdateTransaction(transaction)
	print("Update operation done")

def queryRDF(kp, space, s, p, o):
	transaction = kp.CreateQueryTransaction(space)
	query = [Triple( getResource(s), getResource(p), getResource(o) )]
	result = transaction.rdf_query(query)
	kp.CloseQueryTransaction(transaction)
	print("Query operation done")
	return result

def queryRDFwithListener(kp, space, s, p, o, listener):
	transaction = kp.CreateQueryTransaction(space)
	query = [Triple( getResource(s), getResource(p), getResource(o) )]
	result = transaction.rdf_query(query)
	print("Query operation done")
	for triple in result:
		listener.tripleAdded(str(triple[0]),str(triple[1]),str(triple[2]))
	return len(result)

def subscribeRDF(kp, space, s, p, o, listener):
	transaction = kp.CreateSubscribeTransaction(space)
	query = [Triple( getResource(s), getResource(p), getResource(o) )]
	result = transaction.subscribe_rdf(query, EventHandler(listener))
	print("Subscribe operation done")
	for triple in result:
		listener.tripleAdded(str(triple[0]),str(triple[1]),str(triple[2]))
	return transaction

def unsubscribe(kp, space, transaction):
	kp.CloseSubscribeTransaction(transaction)
	print("Unsubscribe operation done")

def leave(kp, space):
	kp.leave(space)
	print("Leave operation done")
	
class EventHandler:
	def __init__(self, listener):
		self.listener = listener

	def handle(self, added, removed):
		for triple in removed:
			self.listener.tripleRemoved(str(triple[0]),str(triple[1]),str(triple[2]))
		for triple in added:
			self.listener.tripleAdded(str(triple[0]),str(triple[1]),str(triple[2]))

