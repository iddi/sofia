from rdflib import *
from rdflib.graph import Graph
from rdflib.parser import StringInputSource

from smart_m3.ribs_pykpi import *
from sskp import sskp
from sskp import triple

isSSKP = False

def useSSKP(value):
	global isSSKP
	isSSKP = value

def getResourceType(value):
	if value == None:
		return "uri"
	elif value.startswith("http://") :
		return "uri"
	elif value.startswith("_:") :
		return "bnode"
	else :
		return "literal"


def makeTriples(kp, data):
	result = []
	if not data.strip().endswith("."):
		data = data+"."
	store = Graph()
	sourceCode = StringInputSource(data, None)
	store.parse(sourceCode, format='n3')
	ntriples = store.serialize(format="nt")
	for s, p, o in store:
		sub = str(s)
		if not sub.startswith("http://") and ntriples.find("_:"+sub) != -1 :
			sub = "_:"+str(s)
		ob = str(o)
		if not ob.startswith("http://") and ntriples.find("_:"+ob) != -1 :
			ob = "_:"+str(o)
		if isSSKP:
			result.append ( triple.to_triple(sub, str(p), ob, getResourceType(sub),getResourceType(ob)) )
		else:
			result.append ( kp.toTriple(sub, str(p), ob, getResourceType(sub),getResourceType(ob)) )
	return result
	

def insert(kp, s, p, o):
	if isSSKP :
		insert = [triple.to_triple(s, p, o, getResourceType(s),getResourceType(o))]
	else:
		insert = [kp.toTriple(s, p, o, getResourceType(s),getResourceType(o))]
	kp.insert(insert)
	print "Insert operation done"
		
def insert2(kp, data):
	insert = []
	parts = data.split()
	if len(parts) == 3 :
		if isSSKP :
			insert = [triple.to_triple(parts[0], parts[1], parts[2], getResourceType(parts[0]),getResourceType(parts[2]))]
		else :
			insert = [kp.toTriple(parts[0], parts[1], parts[2], getResourceType(parts[0]),getResourceType(parts[2]))]
	else :
		insert = makeTriples(kp, data)
	kp.insert(insert)
	print "Insert operation done"

def remove(kp, s, p, o):
	if isSSKP :
		remove = [triple.to_triple(s, p, o, getResourceType(s),getResourceType(o))]
	else :
		remove = [kp.toTriple(s, p, o, getResourceType(s),getResourceType(o))]
	kp.remove(remove)
	print "Remove operation done"
	
def remove2(kp, data):
	remove = []
	parts = data.split()
	if len(parts) == 3 :
		if isSSKP :
			remove = [triple.to_triple(parts[0], parts[1], parts[2], getResourceType(parts[0]),getResourceType(parts[2]))]
		else :
			remove = [kp.toTriple(parts[0], parts[1], parts[2], getResourceType(parts[0]),getResourceType(parts[2]))]
	else :
		remove = makeTriples(kp, data)
	kp.remove(remove)
	print "Remove operation done"

def update(kp, oldS, oldP, oldO, newS, newP, newO):
	old = []
	new = []
	if isSSKP :
		old = [triple.to_triple(oldS, oldP, oldO, getResourceType(oldS),getResourceType(oldO))]
		new = [triple.to_triple(newS, newP, newO, getResourceType(newS),getResourceType(newO))]
	else:
		old = [kp.toTriple(oldS, oldP, oldO, getResourceType(oldS),getResourceType(oldO))]
		new = [kp.toTriple(newS, newP, newO, getResourceType(newS),getResourceType(newO))]
	kp.update(new, old)
	print "Update operation done"
	
def update2(kp, oldData, newData):
	oparts = oldData.split()
	nparts = newData.split()
	old = []
	new = []
	if isSSKP :
		old = [triple.to_triple( oparts[0], oparts[1], oparts[2], getResourceType(oparts[0]),getResourceType(oparts[2]))]
		new = [triple.to_triple( nparts[0], nparts[1], nparts[2], getResourceType(nparts[0]),getResourceType(nparts[2]))]
	else :
		old = [kp.toTriple( oparts[0], oparts[1], oparts[2], getResourceType(oparts[0]),getResourceType(oparts[2]))]
		new = [kp.toTriple( nparts[0], nparts[1], nparts[2], getResourceType(nparts[0]),getResourceType(nparts[2]))]
	kp.update(new, old)
	print "Update operation done"

def queryRDF(kp, s, p, o):
	result = []
	if isSSKP :
		triples = [triple.to_triple(s, p, o, getResourceType(s),getResourceType(o))]
		result = kp.query(triples)
	else : 		
		result = kp.query(s,p,o,getResourceType(o))
	print "Query operation done:", len(result), "results" 
	#for tr in result:
		#print tr[0].value, tr[1].value, tr[2].value
	return result

def queryRDFwithListener(kp, s, p, o, listener):
	result = []
	if isSSKP :
		triples = [triple.to_triple(s, p, o, getResourceType(s),getResourceType(o))]
		result = kp.query(triples)
	else : 		
		result = kp.query(s,p,o,getResourceType(o))
	print "Query operation done:", len(result), "results" 
	for tr in result:
		listener.tripleAdded(str(tr[0]),str(tr[1]),str(tr[2]))
	return len(result)

def querySPARQL(kp, sparql, listener) :
	result = []
	if isSSKP :
		listener.setSparql(sparql)
		result = kp.sparql_query(sparql)
		print "Query by SPARQL operation done:", len(result), "solutions"
		for solution in result:
			#binding = []
			#for variable in solution:
				#binding.append(solution[variable])
			#listener.dataAdded(binding)
			listener.dataAdded(solution)
		return len(result)
	else :
		result = kp.querySparql(sparql)
		vars, bindings = result
		print "Query by SPARQL operation done:", len(bindings), "solutions"
		for binding in bindings:
			listener.dataAdded(binding)
		return len(bindings)

def subscribeRDF(kp, s, p, o, listener):
	handler = EventHandler(listener)
	subID = -1
	if isSSKP :
		triples = [triple.to_triple(s, p, o, getResourceType(s),getResourceType(o))]
		subId, result = kp.subscribe(triples, handler.handle)
		print "Subscribe operation done:", len(result), "initial results" 
		for tr in result:
			listener.tripleAdded(tr[0].value,tr[1].value,tr[2].value)
	else : 		
		result, subId = kp.subscribe(s,p,o,getResourceType(o),handler.handle)
		print "Subscribe operation done:", len(result), "initial results" 
		for tr in result:
			listener.tripleAdded(str(tr[0]),str(tr[1]),str(tr[2]))
	return subId

def unsubscribe(kp, subID):
	kp.unsubscribe(subID)
	print("Unsubscribe operation done")

def leave(kp):
	kp.leave()
	print("Leave operation done")
	
class EventHandler:
	def __init__(self, listener):
		self.listener = listener

	def handle(self, added, removed):
		print "Subscription indication received"
		for triple in removed:
			self.listener.tripleRemoved(str(triple[0]),str(triple[1]),str(triple[2]))
		for triple in added:
			self.listener.tripleAdded(str(triple[0]),str(triple[1]),str(triple[2]))

class SparqlQueryListener :
	def __init__(self, p) :
		self.parent = p
	def setSparql(self, sparql) :
		self.sparql = sparql
		self.vars = []
		tokens = sparql.split()
		for token in tokens:
			if token.endswith(".") or token.endswith(",") or token.endswith(";") or token.endswith("}") :
				token = token[0:len(token)-1]
			if token.startswith("?") :
				token = token[1:len(token)]
				try:
					self.vars.index(token)
				except ValueError:
					self.vars.append(token)
		
	def dataAdded(self, data) :
		binding = []
		for var in self.vars:
			binding.append(data[var])
		if len(binding)==1 :
			self.solutionAdded(binding[0])
		elif len(binding)==2 :
			self.solutionAdded(binding[0], binding[1])
		elif len(binding)==3 :
			self.solutionAdded(binding[0], binding[1], binding[2])

